import { Router } from 'express';
import { adminController } from '../controllers';
import { authenticate, requireAdmin } from '../middleware/auth';

const router = Router();

// All routes require admin authentication
router.use(authenticate, requireAdmin);

// Dashboard
router.get('/dashboard', adminController.getDashboardStats);

// User management
router.get('/users', adminController.getUsers);
router.get('/users/:id', adminController.getUserById);
router.patch('/users/:id', adminController.updateUser);
router.delete('/users/:id', adminController.deleteUser);

// Past paper management
router.post('/past-papers', adminController.createPastPaper);
router.patch('/past-papers/:id', adminController.updatePastPaper);
router.delete('/past-papers/:id', adminController.deletePastPaper);

// Monthly reset
router.post('/reset', adminController.manualReset);
router.get('/reset-status', adminController.getResetStatus);

// Hall of Fame
router.get('/hall-of-fame', adminController.getHallOfFame);

export default router;
