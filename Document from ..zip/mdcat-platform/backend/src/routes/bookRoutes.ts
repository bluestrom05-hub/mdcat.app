import { Router } from 'express';
import { bookController } from '../controllers';
import { authenticate, requireAdmin } from '../middleware/auth';
import { validate, schemas } from '../middleware/validation';

const router = Router();

// Public routes
router.get('/', bookController.getBooks);
router.get('/:id', bookController.getBookById);

// Admin routes
router.post(
  '/',
  authenticate,
  requireAdmin,
  validate(schemas.createBook),
  bookController.createBook
);
router.delete('/:id', authenticate, requireAdmin, bookController.deleteBook);
router.get('/:id/stats', authenticate, requireAdmin, bookController.getBookStats);

export default router;
