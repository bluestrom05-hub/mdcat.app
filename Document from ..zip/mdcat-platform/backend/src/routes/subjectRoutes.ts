import { Router } from 'express';
import { subjectController } from '../controllers';
import { authenticate, requireAdmin } from '../middleware/auth';
import { validate, schemas } from '../middleware/validation';

const router = Router();

// Public routes
router.get('/', subjectController.getSubjects);
router.get('/:id', subjectController.getSubjectById);

// Admin routes
router.post(
  '/',
  authenticate,
  requireAdmin,
  validate(schemas.createSubject),
  subjectController.createSubject
);
router.patch('/:id', authenticate, requireAdmin, subjectController.updateSubject);
router.delete('/:id', authenticate, requireAdmin, subjectController.deleteSubject);
router.get('/:id/stats', authenticate, requireAdmin, subjectController.getSubjectStats);

export default router;
