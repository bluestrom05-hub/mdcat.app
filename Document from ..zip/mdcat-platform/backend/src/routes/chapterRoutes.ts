import { Router } from 'express';
import { chapterController } from '../controllers';
import { authenticate, requireAdmin } from '../middleware/auth';
import { validate, schemas } from '../middleware/validation';

const router = Router();

// Public routes
router.get('/', chapterController.getChapters);
router.get('/:id', chapterController.getChapterById);

// Admin routes
router.post(
  '/',
  authenticate,
  requireAdmin,
  validate(schemas.createChapter),
  chapterController.createChapter
);
router.patch('/:id', authenticate, requireAdmin, chapterController.updateChapter);
router.delete('/:id', authenticate, requireAdmin, chapterController.deleteChapter);
router.get('/:id/stats', authenticate, requireAdmin, chapterController.getChapterStats);

export default router;
