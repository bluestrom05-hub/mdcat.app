import { Router } from 'express';
import authRoutes from './authRoutes';
import subjectRoutes from './subjectRoutes';
import boardRoutes from './boardRoutes';
import bookRoutes from './bookRoutes';
import chapterRoutes from './chapterRoutes';
import mcqRoutes from './mcqRoutes';
import leaderboardRoutes from './leaderboardRoutes';
import testRoutes from './testRoutes';
import adminRoutes from './adminRoutes';
import premiumRoutes from './premiumRoutes';

const router = Router();

// API routes
router.use('/auth', authRoutes);
router.use('/subjects', subjectRoutes);
router.use('/boards', boardRoutes);
router.use('/books', bookRoutes);
router.use('/chapters', chapterRoutes);
router.use('/mcqs', mcqRoutes);
router.use('/leaderboard', leaderboardRoutes);
router.use('/tests', testRoutes);
router.use('/admin', adminRoutes);
router.use('/premium', premiumRoutes);

// Health check
router.get('/health', (req, res) => {
  res.json({
    success: true,
    message: 'API is running',
    timestamp: new Date().toISOString(),
  });
});

export default router;
