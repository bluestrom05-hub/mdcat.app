import { Router } from 'express';
import multer from 'multer';
import { mcqController } from '../controllers';
import { authenticate, requireAdmin } from '../middleware/auth';
import { validate, schemas } from '../middleware/validation';
import { uploadLimiter } from '../middleware/rateLimiter';

const router = Router();

// Configure multer for memory storage
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB max
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'text/csv' || file.originalname.endsWith('.csv')) {
      cb(null, true);
    } else {
      cb(new Error('Only CSV files are allowed'));
    }
  },
});

// Public routes
router.get('/', mcqController.getMCQs);
router.get('/:id', mcqController.getMCQById);

// Admin routes - Single MCQ
router.post(
  '/',
  authenticate,
  requireAdmin,
  validate(schemas.createMCQ),
  mcqController.createMCQ
);
router.patch('/:id', authenticate, requireAdmin, mcqController.updateMCQ);
router.delete('/:id', authenticate, requireAdmin, mcqController.deleteMCQ);
router.post('/bulk-delete', authenticate, requireAdmin, mcqController.bulkDeleteMCQs);

// Admin routes - CSV Upload
router.get(
  '/template/download',
  authenticate,
  requireAdmin,
  mcqController.downloadCSVTemplate
);
router.post(
  '/upload/preview',
  authenticate,
  requireAdmin,
  uploadLimiter,
  upload.single('file'),
  mcqController.previewCSVUpload
);
router.post(
  '/upload/confirm',
  authenticate,
  requireAdmin,
  mcqController.confirmCSVUpload
);

// Admin routes - Stats
router.get('/:chapterId/counts', authenticate, requireAdmin, mcqController.getMCQCounts);

export default router;
