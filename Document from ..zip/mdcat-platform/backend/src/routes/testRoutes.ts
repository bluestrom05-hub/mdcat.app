import { Router } from 'express';
import { testController } from '../controllers';
import { authenticate } from '../middleware/auth';

const router = Router();

// All routes require authentication
router.use(authenticate);

// Practice routes
router.post('/practice/start', testController.startPractice);

// Past paper routes
router.get('/past-papers', testController.getPastPapers);
router.get('/past-papers/:id', testController.getPastPaperById);
router.post('/past-paper/start', testController.startPastPaper);

// Test session routes
router.post('/answer', testController.saveAnswer);
router.post('/submit', testController.submitTest);
router.post('/auto-submit', testController.autoSubmit);
router.get('/result/:sessionId', testController.getTestResult);
router.get('/history', testController.getTestHistory);

export default router;
