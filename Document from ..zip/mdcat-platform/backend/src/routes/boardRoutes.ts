import { Router } from 'express';
import { boardController } from '../controllers';
import { authenticate, requireAdmin } from '../middleware/auth';
import { validate, schemas } from '../middleware/validation';

const router = Router();

// Public routes
router.get('/', boardController.getBoards);
router.get('/:id', boardController.getBoardById);

// Admin routes
router.post(
  '/',
  authenticate,
  requireAdmin,
  validate(schemas.createBoard),
  boardController.createBoard
);
router.patch('/:id', authenticate, requireAdmin, boardController.updateBoard);
router.delete('/:id', authenticate, requireAdmin, boardController.deleteBoard);

export default router;
