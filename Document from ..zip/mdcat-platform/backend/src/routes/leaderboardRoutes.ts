import { Router } from 'express';
import { leaderboardController } from '../controllers';
import { authenticate, optionalAuth } from '../middleware/auth';
import { leaderboardLimiter } from '../middleware/rateLimiter';

const router = Router();

// Public routes
router.get('/', leaderboardLimiter, leaderboardController.getLeaderboard);
router.get('/top-performers', leaderboardLimiter, leaderboardController.getTopPerformers);

// Protected routes
router.get('/my-rank', authenticate, leaderboardController.getMyRank);

export default router;
