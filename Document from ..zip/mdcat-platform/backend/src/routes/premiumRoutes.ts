import { Router } from 'express';
import { premiumController } from '../controllers';
import { authenticate } from '../middleware/auth';

const router = Router();

// Public route
router.get('/features', premiumController.getPremiumFeatures);

// Protected routes
router.use(authenticate);
router.get('/status', premiumController.getPremiumStatus);
router.post('/purchase', premiumController.initiatePurchase);
router.post('/confirm', premiumController.confirmPurchase);

export default router;
