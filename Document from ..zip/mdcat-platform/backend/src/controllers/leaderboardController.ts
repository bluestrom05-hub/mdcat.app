import { Request, Response } from 'express';
import { leaderboardService } from '../services';
import { asyncHandler } from '../middleware/errorHandler';

// Get leaderboard
export const getLeaderboard = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { month, year, page = 1, limit = 50 } = req.query;

  const now = new Date();
  const targetMonth = month ? parseInt(month as string) : now.getMonth() + 1;
  const targetYear = year ? parseInt(year as string) : now.getFullYear();

  const result = await leaderboardService.getLeaderboard(
    targetMonth,
    targetYear,
    parseInt(page as string),
    parseInt(limit as string)
  );

  res.json({
    success: true,
    data: result.entries,
    meta: {
      page: parseInt(page as string),
      limit: parseInt(limit as string),
      total: result.total,
      totalPages: Math.ceil(result.total / parseInt(limit as string)),
      month: targetMonth,
      year: targetYear,
    },
  });
});

// Get current user's rank
export const getMyRank = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { month, year } = req.query;
  const userId = req.user!.userId;

  const now = new Date();
  const targetMonth = month ? parseInt(month as string) : now.getMonth() + 1;
  const targetYear = year ? parseInt(year as string) : now.getFullYear();

  const rank = await leaderboardService.getUserRank(userId, targetMonth, targetYear);

  if (!rank) {
    res.json({
      success: true,
      data: {
        rank: null,
        score: 0,
        message: 'No score recorded for this month yet',
      },
    });
    return;
  }

  res.json({
    success: true,
    data: rank,
  });
});

// Get top 3 performers (for homepage)
export const getTopPerformers = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { month, year } = req.query;

  const now = new Date();
  const targetMonth = month ? parseInt(month as string) : now.getMonth() + 1;
  const targetYear = year ? parseInt(year as string) : now.getFullYear();

  const topPerformers = await leaderboardService.getTopPerformers(targetMonth, targetYear);

  res.json({
    success: true,
    data: topPerformers,
    meta: {
      month: targetMonth,
      year: targetYear,
    },
  });
});
