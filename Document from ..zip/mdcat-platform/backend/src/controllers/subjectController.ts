import { Request, Response } from 'express';
import { Subject, Book, Chapter, MCQ } from '../models';
import { asyncHandler, AppError } from '../middleware/errorHandler';

// Get all subjects
export const getSubjects = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const subjects = await Subject.find().sort({ name: 1 });

  res.json({
    success: true,
    data: subjects,
  });
});

// Get subject by ID with hierarchy
export const getSubjectById = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;

  const subject = await Subject.findById(id);
  if (!subject) {
    throw new AppError('Subject not found', 404);
  }

  // Get books if science subject
  let books = [];
  if (subject.type === 'science') {
    books = await Book.find({ subjectId: id })
      .populate('boardId', 'name code')
      .sort({ class: 1 });
  }

  res.json({
    success: true,
    data: {
      subject,
      books,
    },
  });
});

// Create subject (admin only)
export const createSubject = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { name, code, type, description } = req.body;

  // Check if code already exists
  const existing = await Subject.findOne({ code: code.toUpperCase() });
  if (existing) {
    throw new AppError('Subject with this code already exists', 409);
  }

  const subject = await Subject.create({
    name,
    code: code.toUpperCase(),
    type,
    description,
  });

  res.status(201).json({
    success: true,
    message: 'Subject created successfully',
    data: subject,
  });
});

// Update subject (admin only)
export const updateSubject = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;
  const { name, description } = req.body;

  const subject = await Subject.findByIdAndUpdate(
    id,
    { name, description },
    { new: true, runValidators: true }
  );

  if (!subject) {
    throw new AppError('Subject not found', 404);
  }

  res.json({
    success: true,
    message: 'Subject updated successfully',
    data: subject,
  });
});

// Delete subject with cascade (admin only)
export const deleteSubject = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;

  const subject = await Subject.findById(id);
  if (!subject) {
    throw new AppError('Subject not found', 404);
  }

  // Get all books for this subject
  const books = await Book.find({ subjectId: id });
  const bookIds = books.map((b) => b._id.toString());

  // Get all chapters for these books
  const chapters = await Chapter.find({ bookId: { $in: bookIds } });
  const chapterIds = chapters.map((c) => c._id.toString());

  // Delete all related data
  await Promise.all([
    MCQ.deleteMany({ subjectId: id }),
    MCQ.deleteMany({ chapterId: { $in: chapterIds } }),
    Chapter.deleteMany({ bookId: { $in: bookIds } }),
    Book.deleteMany({ subjectId: id }),
    Subject.findByIdAndDelete(id),
  ]);

  res.json({
    success: true,
    message: 'Subject and all related data deleted successfully',
  });
});

// Get subject stats (admin only)
export const getSubjectStats = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;

  const subject = await Subject.findById(id);
  if (!subject) {
    throw new AppError('Subject not found', 404);
  }

  let stats: any = {
    subject: subject.name,
  };

  if (subject.type === 'science') {
    const books = await Book.find({ subjectId: id });
    const bookIds = books.map((b) => b._id.toString());
    const chapters = await Chapter.find({ bookId: { $in: bookIds } });
    const chapterIds = chapters.map((c) => c._id.toString());
    const mcqCount = await MCQ.countDocuments({ chapterId: { $in: chapterIds } });

    stats = {
      ...stats,
      bookCount: books.length,
      chapterCount: chapters.length,
      mcqCount,
    };
  } else {
    const mcqCount = await MCQ.countDocuments({ subjectId: id });
    stats = {
      ...stats,
      mcqCount,
    };
  }

  res.json({
    success: true,
    data: stats,
  });
});
