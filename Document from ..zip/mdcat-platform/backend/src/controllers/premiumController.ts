import { Request, Response } from 'express';
import { User } from '../models';
import { asyncHandler, AppError } from '../middleware/errorHandler';
import { CONSTANTS } from '../types';

// Get premium status
export const getPremiumStatus = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const userId = req.user!.userId;

  const user = await User.findById(userId).select('isPremium premiumSince');
  if (!user) {
    throw new AppError('User not found', 404);
  }

  res.json({
    success: true,
    data: {
      isPremium: user.isPremium,
      premiumSince: user.premiumSince,
      price: CONSTANTS.PREMIUM_PRICE,
      currency: 'PKR',
    },
  });
});

// Initiate premium purchase (mock payment)
export const initiatePurchase = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const userId = req.user!.userId;

  const user = await User.findById(userId);
  if (!user) {
    throw new AppError('User not found', 404);
  }

  if (user.isPremium) {
    throw new AppError('User already has premium status', 400);
  }

  // Mock payment gateway integration
  // In production, this would redirect to a real payment gateway
  const mockPaymentId = `PAY_${Date.now()}_${userId}`;

  res.json({
    success: true,
    message: 'Payment initiated',
    data: {
      paymentId: mockPaymentId,
      amount: CONSTANTS.PREMIUM_PRICE,
      currency: 'PKR',
      // In production, include payment gateway URL
      paymentUrl: `/api/premium/confirm`,
    },
  });
});

// Confirm premium purchase (mock callback)
export const confirmPurchase = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const userId = req.user!.userId;
  const { paymentId, status } = req.body;

  const user = await User.findById(userId);
  if (!user) {
    throw new AppError('User not found', 404);
  }

  if (user.isPremium) {
    throw new AppError('User already has premium status', 400);
  }

  // Mock payment verification
  // In production, verify with actual payment gateway
  const isPaymentSuccessful = status === 'success' || !status;

  if (!isPaymentSuccessful) {
    throw new AppError('Payment failed', 400);
  }

  // Grant premium
  user.isPremium = true;
  user.premiumSince = new Date();
  await user.save();

  res.json({
    success: true,
    message: 'Premium activated successfully',
    data: {
      isPremium: true,
      premiumSince: user.premiumSince,
    },
  });
});

// Get premium features info
export const getPremiumFeatures = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  res.json({
    success: true,
    data: {
      price: CONSTANTS.PREMIUM_PRICE,
      currency: 'PKR',
      features: [
        {
          title: 'No Ads',
          description: 'Enjoy an ad-free learning experience',
        },
        {
          title: 'Custom Themes',
          description: 'Access to dark mode and custom themes',
        },
        {
          title: 'Premium Badge',
          description: 'Exclusive badge on your profile and leaderboard',
        },
        {
          title: 'Advanced Stats',
          description: 'Detailed analytics and progress tracking',
        },
        {
          title: 'Priority Support',
          description: 'Get priority customer support',
        },
      ],
    },
  });
});
