import { Request, Response } from 'express';
import { Chapter, MCQ, Book } from '../models';
import { asyncHandler, AppError } from '../middleware/errorHandler';
import { CONSTANTS } from '../types';

// Get all chapters
export const getChapters = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { bookId, subjectId } = req.query;

  const query: any = {};
  if (bookId) query.bookId = bookId;
  if (subjectId) query.subjectId = subjectId;

  const chapters = await Chapter.find(query)
    .populate('bookId', 'title')
    .populate('subjectId', 'name code')
    .sort({ number: 1 });

  res.json({
    success: true,
    data: chapters,
  });
});

// Get chapter by ID with MCQs
export const getChapterById = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;
  const { page = 1, limit = 20 } = req.query;

  const chapter = await Chapter.findById(id)
    .populate('bookId', 'title')
    .populate('subjectId', 'name code');

  if (!chapter) {
    throw new AppError('Chapter not found', 404);
  }

  // Get MCQs with pagination
  const pageNum = parseInt(page as string);
  const limitNum = parseInt(limit as string);
  const skip = (pageNum - 1) * limitNum;

  const [mcqs, totalMcqs] = await Promise.all([
    MCQ.find({ chapterId: id })
      .skip(skip)
      .limit(limitNum)
      .sort({ createdAt: -1 }),
    MCQ.countDocuments({ chapterId: id }),
  ]);

  res.json({
    success: true,
    data: {
      chapter,
      mcqs,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total: totalMcqs,
        totalPages: Math.ceil(totalMcqs / limitNum),
      },
    },
  });
});

// Create chapter (admin only)
export const createChapter = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { bookId, name, number } = req.body;

  // Validate book
  const book = await Book.findById(bookId);
  if (!book) {
    throw new AppError('Book not found', 404);
  }

  // Check chapter limit
  const chapterCount = await Chapter.countDocuments({ bookId });
  if (chapterCount >= CONSTANTS.MAX_CHAPTERS_PER_BOOK) {
    throw new AppError(
      `Maximum ${CONSTANTS.MAX_CHAPTERS_PER_BOOK} chapters allowed per book`,
      400
    );
  }

  // Check if chapter number already exists
  const existing = await Chapter.findOne({ bookId, number });
  if (existing) {
    throw new AppError('Chapter number already exists for this book', 409);
  }

  const chapter = await Chapter.create({
    bookId,
    subjectId: book.subjectId,
    name,
    number,
    mcqCount: 0,
  });

  res.status(201).json({
    success: true,
    message: 'Chapter created successfully',
    data: chapter,
  });
});

// Update chapter (admin only)
export const updateChapter = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;
  const { name, number } = req.body;

  const chapter = await Chapter.findById(id);
  if (!chapter) {
    throw new AppError('Chapter not found', 404);
  }

  // Check if new number conflicts
  if (number && number !== chapter.number) {
    const existing = await Chapter.findOne({
      bookId: chapter.bookId,
      number,
      _id: { $ne: id },
    });
    if (existing) {
      throw new AppError('Chapter number already exists for this book', 409);
    }
  }

  const updated = await Chapter.findByIdAndUpdate(
    id,
    { name, number },
    { new: true, runValidators: true }
  );

  res.json({
    success: true,
    message: 'Chapter updated successfully',
    data: updated,
  });
});

// Delete chapter with cascade (admin only)
export const deleteChapter = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;

  const chapter = await Chapter.findById(id);
  if (!chapter) {
    throw new AppError('Chapter not found', 404);
  }

  // Delete all MCQs in this chapter
  await MCQ.deleteMany({ chapterId: id });

  // Update book's chapter count
  await Book.findByIdAndUpdate(chapter.bookId, {
    $inc: { chapterCount: -1 },
  });

  // Delete chapter
  await Chapter.findByIdAndDelete(id);

  res.json({
    success: true,
    message: 'Chapter and all associated MCQs deleted successfully',
  });
});

// Get chapter stats (admin only)
export const getChapterStats = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;

  const chapter = await Chapter.findById(id);
  if (!chapter) {
    throw new AppError('Chapter not found', 404);
  }

  res.json({
    success: true,
    data: {
      chapter: chapter.name,
      mcqCount: chapter.mcqCount,
      maxMcqs: chapter.maxMcqs,
      remainingSlots: chapter.maxMcqs - chapter.mcqCount,
    },
  });
});
