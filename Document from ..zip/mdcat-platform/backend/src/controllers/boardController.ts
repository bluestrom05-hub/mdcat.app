import { Request, Response } from 'express';
import { Board, Book, Chapter, MCQ } from '../models';
import { asyncHandler, AppError } from '../middleware/errorHandler';

// Get all boards
export const getBoards = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const boards = await Board.find().sort({ name: 1 });

  res.json({
    success: true,
    data: boards,
  });
});

// Get board by ID
export const getBoardById = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;

  const board = await Board.findById(id);
  if (!board) {
    throw new AppError('Board not found', 404);
  }

  // Get books for this board
  const books = await Book.find({ boardId: id })
    .populate('subjectId', 'name code')
    .sort({ class: 1 });

  res.json({
    success: true,
    data: {
      board,
      books,
    },
  });
});

// Create board (admin only)
export const createBoard = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { name, code, description } = req.body;

  // Check if code already exists
  const existing = await Board.findOne({ code: code.toUpperCase() });
  if (existing) {
    throw new AppError('Board with this code already exists', 409);
  }

  const board = await Board.create({
    name,
    code: code.toUpperCase(),
    description,
  });

  res.status(201).json({
    success: true,
    message: 'Board created successfully',
    data: board,
  });
});

// Update board (admin only)
export const updateBoard = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;
  const { name, description } = req.body;

  const board = await Board.findByIdAndUpdate(
    id,
    { name, description },
    { new: true, runValidators: true }
  );

  if (!board) {
    throw new AppError('Board not found', 404);
  }

  res.json({
    success: true,
    message: 'Board updated successfully',
    data: board,
  });
});

// Delete board with cascade (admin only)
export const deleteBoard = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;

  const board = await Board.findById(id);
  if (!board) {
    throw new AppError('Board not found', 404);
  }

  // Get all books for this board
  const books = await Book.find({ boardId: id });
  const bookIds = books.map((b) => b._id.toString());

  // Get all chapters for these books
  const chapters = await Chapter.find({ bookId: { $in: bookIds } });
  const chapterIds = chapters.map((c) => c._id.toString());

  // Delete all related data
  await Promise.all([
    MCQ.deleteMany({ chapterId: { $in: chapterIds } }),
    Chapter.deleteMany({ bookId: { $in: bookIds } }),
    Book.deleteMany({ boardId: id }),
    Board.findByIdAndDelete(id),
  ]);

  res.json({
    success: true,
    message: 'Board and all related data deleted successfully',
  });
});
