import { Request, Response } from 'express';
import { TestSession, PastPaper, MCQ, Chapter } from '../models';
import { scoringService } from '../services';
import { asyncHandler, AppError } from '../middleware/errorHandler';
import { CONSTANTS } from '../types';

// Start a practice session
export const startPractice = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { chapterId } = req.body;
  const userId = req.user!.userId;

  // Validate chapter
  const chapter = await Chapter.findById(chapterId);
  if (!chapter) {
    throw new AppError('Chapter not found', 404);
  }

  // Get MCQs for this chapter
  const mcqs = await MCQ.find({ chapterId }).select('_id');
  if (mcqs.length === 0) {
    throw new AppError('No MCQs found in this chapter', 400);
  }

  // Create test session
  const session = await TestSession.create({
    userId,
    chapterId,
    sessionType: 'practice',
    answers: new Map(),
    startTime: new Date(),
    score: 0,
    correctCount: 0,
    wrongCount: 0,
    isCompleted: false,
  });

  res.status(201).json({
    success: true,
    message: 'Practice session started',
    data: {
      sessionId: session._id,
      mcqCount: mcqs.length,
      mcqs: mcqs.map((m) => m._id),
    },
  });
});

// Start a past paper test
export const startPastPaper = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { pastPaperId } = req.body;
  const userId = req.user!.userId;

  // Validate past paper
  const pastPaper = await PastPaper.findById(pastPaperId);
  if (!pastPaper) {
    throw new AppError('Past paper not found', 404);
  }

  if (!pastPaper.isActive) {
    throw new AppError('This past paper is not available', 400);
  }

  // Check if user already has an incomplete session
  const existingSession = await TestSession.findOne({
    userId,
    pastPaperId,
    isCompleted: false,
  });

  if (existingSession) {
    // Return existing session
    const mcqs = await MCQ.find({ _id: { $in: pastPaper.mcqs } });
    
    res.json({
      success: true,
      message: 'Resuming existing session',
      data: {
        sessionId: existingSession._id,
        pastPaper: {
          title: pastPaper.title,
          year: pastPaper.year,
          totalMarks: pastPaper.totalMarks,
          duration: pastPaper.duration,
        },
        mcqs,
        startTime: existingSession.startTime,
      },
    });
    return;
  }

  // Create new test session
  const session = await TestSession.create({
    userId,
    pastPaperId,
    sessionType: 'past_paper',
    answers: new Map(),
    startTime: new Date(),
    score: 0,
    correctCount: 0,
    wrongCount: 0,
    isCompleted: false,
  });

  // Get MCQs
  const mcqs = await MCQ.find({ _id: { $in: pastPaper.mcqs } });

  res.status(201).json({
    success: true,
    message: 'Past paper test started',
    data: {
      sessionId: session._id,
      pastPaper: {
        title: pastPaper.title,
        year: pastPaper.year,
        totalMarks: pastPaper.totalMarks,
        duration: pastPaper.duration,
      },
      mcqs,
      startTime: session.startTime,
    },
  });
});

// Save answer during test
export const saveAnswer = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { sessionId, mcqId, answer } = req.body;
  const userId = req.user!.userId;

  const session = await TestSession.findOne({ _id: sessionId, userId });
  if (!session) {
    throw new AppError('Test session not found', 404);
  }

  if (session.isCompleted) {
    throw new AppError('Test already completed', 400);
  }

  // Validate answer
  const validAnswers = ['A', 'B', 'C', 'D'];
  if (!validAnswers.includes(answer.toUpperCase())) {
    throw new AppError('Invalid answer. Must be A, B, C, or D', 400);
  }

  // Save answer
  session.answers.set(mcqId, answer.toUpperCase());
  await session.save();

  res.json({
    success: true,
    message: 'Answer saved',
  });
});

// Submit test
export const submitTest = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { sessionId } = req.body;
  const userId = req.user!.userId;

  const session = await TestSession.findOne({ _id: sessionId, userId });
  if (!session) {
    throw new AppError('Test session not found', 404);
  }

  if (session.isCompleted) {
    throw new AppError('Test already submitted', 400);
  }

  // Submit and calculate result
  const result = await scoringService.submitTest(
    sessionId,
    session.answers,
    userId
  );

  // Format time taken
  const minutes = Math.floor(result.timeTaken / 60);
  const seconds = result.timeTaken % 60;

  res.json({
    success: true,
    message: 'Test submitted successfully',
    data: {
      result: {
        ...result,
        timeTakenFormatted: `${minutes}m ${seconds}s`,
      },
    },
  });
});

// Auto-submit when time expires
export const autoSubmit = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { sessionId } = req.body;
  const userId = req.user!.userId;

  const result = await scoringService.autoSubmit(sessionId, userId);

  const minutes = Math.floor(result.timeTaken / 60);
  const seconds = result.timeTaken % 60;

  res.json({
    success: true,
    message: 'Test auto-submitted',
    data: {
      result: {
        ...result,
        timeTakenFormatted: `${minutes}m ${seconds}s`,
      },
    },
  });
});

// Get test result
export const getTestResult = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { sessionId } = req.params;
  const userId = req.user!.userId;

  const session = await TestSession.findOne({ _id: sessionId, userId })
    .populate('pastPaperId', 'title year')
    .populate('chapterId', 'name');

  if (!session) {
    throw new AppError('Test session not found', 404);
  }

  if (!session.isCompleted) {
    throw new AppError('Test not completed yet', 400);
  }

  const minutes = Math.floor((session.endTime!.getTime() - session.startTime.getTime()) / 60000);
  const seconds = Math.floor(((session.endTime!.getTime() - session.startTime.getTime()) % 60000) / 1000);

  res.json({
    success: true,
    data: {
      session: {
        id: session._id,
        type: session.sessionType,
        pastPaper: session.pastPaperId,
        chapter: session.chapterId,
        score: session.score,
        correctCount: session.correctCount,
        wrongCount: session.wrongCount,
        timeTaken: `${minutes}m ${seconds}s`,
        completedAt: session.endTime,
      },
    },
  });
});

// Get test history
export const getTestHistory = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const userId = req.user!.userId;
  const { page = 1, limit = 10 } = req.query;

  const result = await scoringService.getTestHistory(
    userId,
    parseInt(page as string),
    parseInt(limit as string)
  );

  res.json({
    success: true,
    data: result.sessions,
    meta: {
      page: parseInt(page as string),
      limit: parseInt(limit as string),
      total: result.total,
      totalPages: Math.ceil(result.total / parseInt(limit as string)),
    },
  });
});

// Get past papers
export const getPastPapers = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { year, page = 1, limit = 10 } = req.query;

  const query: any = { isActive: true };
  if (year) query.year = parseInt(year as string);

  const skip = (parseInt(page as string) - 1) * parseInt(limit as string);

  const [pastPapers, total] = await Promise.all([
    PastPaper.find(query)
      .select('title year totalMarks duration')
      .sort({ year: -1 })
      .skip(skip)
      .limit(parseInt(limit as string)),
    PastPaper.countDocuments(query),
  ]);

  res.json({
    success: true,
    data: pastPapers,
    meta: {
      page: parseInt(page as string),
      limit: parseInt(limit as string),
      total,
      totalPages: Math.ceil(total / parseInt(limit as string)),
    },
  });
});

// Get past paper by ID
export const getPastPaperById = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;

  const pastPaper = await PastPaper.findById(id);
  if (!pastPaper) {
    throw new AppError('Past paper not found', 404);
  }

  const mcqs = await MCQ.find({ _id: { $in: pastPaper.mcqs } });

  res.json({
    success: true,
    data: {
      pastPaper,
      mcqs,
    },
  });
});
