import { Request, Response } from 'express';
import { User, PastPaper, MCQ, MonthlyScore, HallOfFame, Subject } from '../models';
import { monthlyResetService } from '../services';
import { asyncHandler, AppError } from '../middleware/errorHandler';

// Get dashboard stats
export const getDashboardStats = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const now = new Date();
  const currentMonth = now.getMonth() + 1;
  const currentYear = now.getFullYear();

  const [
    totalUsers,
    totalMCQs,
    totalPastPapers,
    monthlyParticipants,
    premiumUsers,
  ] = await Promise.all([
    User.countDocuments(),
    MCQ.countDocuments(),
    PastPaper.countDocuments(),
    MonthlyScore.countDocuments({ month: currentMonth, year: currentYear }),
    User.countDocuments({ isPremium: true }),
  ]);

  // Get subject-wise MCQ counts
  const subjects = await Subject.find();
  const subjectStats = await Promise.all(
    subjects.map(async (subject) => {
      const count = await MCQ.countDocuments({ subjectId: subject._id });
      return {
        name: subject.name,
        code: subject.code,
        mcqCount: count,
      };
    })
  );

  res.json({
    success: true,
    data: {
      users: {
        total: totalUsers,
        premium: premiumUsers,
      },
      content: {
        totalMCQs,
        totalPastPapers,
        subjectStats,
      },
      competition: {
        monthlyParticipants,
        currentMonth,
        currentYear,
      },
    },
  });
});

// Get all users
export const getUsers = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { search, page = 1, limit = 20 } = req.query;

  const query: any = {};
  if (search) {
    query.$or = [
      { name: { $regex: search, $options: 'i' } },
      { email: { $regex: search, $options: 'i' } },
    ];
  }

  const skip = (parseInt(page as string) - 1) * parseInt(limit as string);

  const [users, total] = await Promise.all([
    User.find(query)
      .select('-password')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit as string)),
    User.countDocuments(query),
  ]);

  res.json({
    success: true,
    data: users,
    meta: {
      page: parseInt(page as string),
      limit: parseInt(limit as string),
      total,
      totalPages: Math.ceil(total / parseInt(limit as string)),
    },
  });
});

// Get user by ID
export const getUserById = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;

  const user = await User.findById(id).select('-password');
  if (!user) {
    throw new AppError('User not found', 404);
  }

  // Get user's test history
  const testCount = await (await import('../models/TestSession')).default.countDocuments({
    userId: id,
    isCompleted: true,
  });

  res.json({
    success: true,
    data: {
      user,
      stats: {
        testsCompleted: testCount,
      },
    },
  });
});

// Update user (grant/revoke premium)
export const updateUser = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;
  const { isPremium, role } = req.body;

  const user = await User.findById(id);
  if (!user) {
    throw new AppError('User not found', 404);
  }

  const updates: any = {};
  if (typeof isPremium === 'boolean') {
    updates.isPremium = isPremium;
    if (isPremium && !user.isPremium) {
      updates.premiumSince = new Date();
    }
  }
  if (role && ['user', 'admin'].includes(role)) {
    updates.role = role;
  }

  const updated = await User.findByIdAndUpdate(id, updates, { new: true }).select('-password');

  res.json({
    success: true,
    message: 'User updated successfully',
    data: updated,
  });
});

// Delete user
export const deleteUser = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;

  const user = await User.findById(id);
  if (!user) {
    throw new AppError('User not found', 404);
  }

  // Prevent deleting yourself
  if (id === req.user!.userId) {
    throw new AppError('Cannot delete your own account', 400);
  }

  await User.findByIdAndDelete(id);

  res.json({
    success: true,
    message: 'User deleted successfully',
  });
});

// Create past paper (admin only)
export const createPastPaper = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { title, year, mcqIds } = req.body;

  // Validate MCQs
  const mcqs = await MCQ.find({ _id: { $in: mcqIds } });
  if (mcqs.length !== mcqIds.length) {
    throw new AppError('Some MCQs not found', 400);
  }

  const pastPaper = await PastPaper.create({
    title,
    year,
    mcqs: mcqIds,
    totalMarks: mcqIds.length,
    duration: 180, // 3 hours
    isActive: true,
  });

  res.status(201).json({
    success: true,
    message: 'Past paper created successfully',
    data: pastPaper,
  });
});

// Update past paper (admin only)
export const updatePastPaper = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;
  const { title, year, mcqIds, isActive } = req.body;

  const pastPaper = await PastPaper.findById(id);
  if (!pastPaper) {
    throw new AppError('Past paper not found', 404);
  }

  const updates: any = {};
  if (title) updates.title = title;
  if (year) updates.year = year;
  if (typeof isActive === 'boolean') updates.isActive = isActive;
  if (mcqIds) {
    const mcqs = await MCQ.find({ _id: { $in: mcqIds } });
    if (mcqs.length !== mcqIds.length) {
      throw new AppError('Some MCQs not found', 400);
    }
    updates.mcqs = mcqIds;
    updates.totalMarks = mcqIds.length;
  }

  const updated = await PastPaper.findByIdAndUpdate(id, updates, { new: true });

  res.json({
    success: true,
    message: 'Past paper updated successfully',
    data: updated,
  });
});

// Delete past paper (admin only)
export const deletePastPaper = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;

  const pastPaper = await PastPaper.findById(id);
  if (!pastPaper) {
    throw new AppError('Past paper not found', 404);
  }

  await PastPaper.findByIdAndDelete(id);

  res.json({
    success: true,
    message: 'Past paper deleted successfully',
  });
});

// Trigger manual monthly reset (admin only)
export const manualReset = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { month, year } = req.body;

  if (monthlyResetService.isResetRunning()) {
    throw new AppError('Reset already in progress', 400);
  }

  await monthlyResetService.manualReset(month, year);

  res.json({
    success: true,
    message: 'Monthly reset completed successfully',
  });
});

// Get Hall of Fame
export const getHallOfFame = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { month, year, page = 1, limit = 10 } = req.query;

  const result = await monthlyResetService.getHallOfFame(
    month ? parseInt(month as string) : undefined,
    year ? parseInt(year as string) : undefined,
    parseInt(page as string),
    parseInt(limit as string)
  );

  res.json({
    success: true,
    data: result.entries,
    meta: {
      page: parseInt(page as string),
      limit: parseInt(limit as string),
      total: result.total,
      totalPages: Math.ceil(result.total / parseInt(limit as string)),
    },
  });
});

// Get reset status
export const getResetStatus = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  res.json({
    success: true,
    data: {
      isRunning: monthlyResetService.isResetRunning(),
    },
  });
});
