import { Request, Response } from 'express';
import { Book, Chapter, MCQ, Subject, Board } from '../models';
import { asyncHandler, AppError } from '../middleware/errorHandler';
import { CONSTANTS } from '../types';

// Get all books
export const getBooks = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { subjectId, boardId, class: classNum } = req.query;

  const query: any = {};
  if (subjectId) query.subjectId = subjectId;
  if (boardId) query.boardId = boardId;
  if (classNum) query.class = parseInt(classNum as string);

  const books = await Book.find(query)
    .populate('subjectId', 'name code')
    .populate('boardId', 'name code')
    .sort({ createdAt: -1 });

  res.json({
    success: true,
    data: books,
  });
});

// Get book by ID with chapters
export const getBookById = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;

  const book = await Book.findById(id)
    .populate('subjectId', 'name code')
    .populate('boardId', 'name code');

  if (!book) {
    throw new AppError('Book not found', 404);
  }

  // Get chapters
  const chapters = await Chapter.find({ bookId: id })
    .sort({ number: 1 });

  res.json({
    success: true,
    data: {
      book,
      chapters,
    },
  });
});

// Create or get book (auto-generation)
export const createBook = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { subjectId, boardId, class: classNum } = req.body;

  // Validate subject
  const subject = await Subject.findById(subjectId);
  if (!subject) {
    throw new AppError('Subject not found', 404);
  }

  // Validate board
  const board = await Board.findById(boardId);
  if (!board) {
    throw new AppError('Board not found', 404);
  }

  // Check if book already exists
  let book = await Book.findOne({ subjectId, boardId, class: classNum });

  if (book) {
    res.json({
      success: true,
      message: 'Book already exists',
      data: book,
    });
    return;
  }

  // Create new book
  book = await Book.create({
    subjectId,
    boardId,
    class: classNum,
    title: `${subject.name} - ${board.name} - Class ${classNum}`,
    chapterCount: 0,
    mcqCount: 0,
  });

  res.status(201).json({
    success: true,
    message: 'Book created successfully',
    data: book,
  });
});

// Delete book with cascade (admin only)
export const deleteBook = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;

  const book = await Book.findById(id);
  if (!book) {
    throw new AppError('Book not found', 404);
  }

  // Get all chapters for this book
  const chapters = await Chapter.find({ bookId: id });
  const chapterIds = chapters.map((c) => c._id.toString());

  // Delete all related data
  await Promise.all([
    MCQ.deleteMany({ chapterId: { $in: chapterIds } }),
    Chapter.deleteMany({ bookId: id }),
    Book.findByIdAndDelete(id),
  ]);

  res.json({
    success: true,
    message: 'Book and all related data deleted successfully',
  });
});

// Get book stats (admin only)
export const getBookStats = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;

  const book = await Book.findById(id);
  if (!book) {
    throw new AppError('Book not found', 404);
  }

  const chapters = await Chapter.find({ bookId: id });
  const chapterIds = chapters.map((c) => c._id.toString());
  const mcqCount = await MCQ.countDocuments({ chapterId: { $in: chapterIds } });

  res.json({
    success: true,
    data: {
      book: book.title,
      chapterCount: chapters.length,
      maxChapters: CONSTANTS.MAX_CHAPTERS_PER_BOOK,
      remainingChapters: CONSTANTS.MAX_CHAPTERS_PER_BOOK - chapters.length,
      mcqCount,
      chapters: chapters.map((c) => ({
        id: c._id,
        name: c.name,
        mcqCount: c.mcqCount,
        maxMcqs: c.maxMcqs,
        remainingSlots: c.maxMcqs - c.mcqCount,
      })),
    },
  });
});
