import { Request, Response } from 'express';
import { MCQ, Chapter, Subject, Book } from '../models';
import { asyncHandler, AppError } from '../middleware/errorHandler';
import { csvUploadService } from '../services';
import { CONSTANTS } from '../types';

// Get all MCQs with filters
export const getMCQs = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { chapterId, subjectId, search, page = 1, limit = 20 } = req.query;

  const query: any = {};
  if (chapterId) query.chapterId = chapterId;
  if (subjectId) query.subjectId = subjectId;
  if (search) {
    query.$or = [
      { question: { $regex: search, $options: 'i' } },
      { explanation: { $regex: search, $options: 'i' } },
    ];
  }

  const pageNum = parseInt(page as string);
  const limitNum = parseInt(limit as string);
  const skip = (pageNum - 1) * limitNum;

  const [mcqs, total] = await Promise.all([
    MCQ.find(query)
      .populate('chapterId', 'name')
      .populate('subjectId', 'name code')
      .skip(skip)
      .limit(limitNum)
      .sort({ createdAt: -1 }),
    MCQ.countDocuments(query),
  ]);

  res.json({
    success: true,
    data: mcqs,
    meta: {
      page: pageNum,
      limit: limitNum,
      total,
      totalPages: Math.ceil(total / limitNum),
    },
  });
});

// Get MCQ by ID
export const getMCQById = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;

  const mcq = await MCQ.findById(id)
    .populate('chapterId', 'name')
    .populate('subjectId', 'name code')
    .populate('bookId', 'title');

  if (!mcq) {
    throw new AppError('MCQ not found', 404);
  }

  res.json({
    success: true,
    data: mcq,
  });
});

// Create single MCQ (admin only)
export const createMCQ = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const {
    chapterId,
    question,
    optionA,
    optionB,
    optionC,
    optionD,
    correctAnswer,
    explanation,
  } = req.body;

  // Validate chapter
  const chapter = await Chapter.findById(chapterId);
  if (!chapter) {
    throw new AppError('Chapter not found', 404);
  }

  // Check chapter MCQ limit
  if (chapter.mcqCount >= chapter.maxMcqs) {
    throw new AppError(
      `Maximum ${chapter.maxMcqs} MCQs allowed per chapter. Current: ${chapter.mcqCount}`,
      400
    );
  }

  // Check subject limits for English and Logical Reasoning
  const subject = await Subject.findById(chapter.subjectId);
  if (subject) {
    if (subject.code === 'ENG') {
      const englishMcqCount = await MCQ.countDocuments({ subjectId: chapter.subjectId });
      if (englishMcqCount >= CONSTANTS.MAX_MCQS_ENGLISH) {
        throw new AppError(
          `Maximum ${CONSTANTS.MAX_MCQS_ENGLISH} MCQs allowed for English`,
          400
        );
      }
    }

    if (subject.code === 'LR') {
      const logicalMcqCount = await MCQ.countDocuments({ subjectId: chapter.subjectId });
      if (logicalMcqCount >= CONSTANTS.MAX_MCQS_LOGICAL) {
        throw new AppError(
          `Maximum ${CONSTANTS.MAX_MCQS_LOGICAL} MCQs allowed for Logical Reasoning`,
          400
        );
      }
    }
  }

  // Check for duplicate question
  const existing = await MCQ.findOne({
    chapterId,
    question: { $regex: new RegExp(`^${question.trim()}$`, 'i') },
  });

  if (existing) {
    throw new AppError('Question already exists in this chapter', 409);
  }

  // Get bookId if exists
  const book = await Book.findOne({ subjectId: chapter.subjectId });

  const mcq = await MCQ.create({
    chapterId,
    subjectId: chapter.subjectId,
    bookId: book?._id,
    question: question.trim(),
    optionA: optionA.trim(),
    optionB: optionB.trim(),
    optionC: optionC.trim(),
    optionD: optionD.trim(),
    correctAnswer: correctAnswer.toUpperCase(),
    explanation: explanation?.trim() || '',
  });

  res.status(201).json({
    success: true,
    message: 'MCQ created successfully',
    data: mcq,
  });
});

// Update MCQ (admin only)
export const updateMCQ = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;
  const {
    question,
    optionA,
    optionB,
    optionC,
    optionD,
    correctAnswer,
    explanation,
  } = req.body;

  const mcq = await MCQ.findById(id);
  if (!mcq) {
    throw new AppError('MCQ not found', 404);
  }

  // Check for duplicate if question changed
  if (question && question !== mcq.question) {
    const existing = await MCQ.findOne({
      chapterId: mcq.chapterId,
      question: { $regex: new RegExp(`^${question.trim()}$`, 'i') },
      _id: { $ne: id },
    });

    if (existing) {
      throw new AppError('Question already exists in this chapter', 409);
    }
  }

  const updated = await MCQ.findByIdAndUpdate(
    id,
    {
      question: question?.trim(),
      optionA: optionA?.trim(),
      optionB: optionB?.trim(),
      optionC: optionC?.trim(),
      optionD: optionD?.trim(),
      correctAnswer: correctAnswer?.toUpperCase(),
      explanation: explanation?.trim(),
    },
    { new: true, runValidators: true }
  );

  res.json({
    success: true,
    message: 'MCQ updated successfully',
    data: updated,
  });
});

// Delete MCQ (admin only)
export const deleteMCQ = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { id } = req.params;

  const mcq = await MCQ.findById(id);
  if (!mcq) {
    throw new AppError('MCQ not found', 404);
  }

  await MCQ.findByIdAndDelete(id);

  res.json({
    success: true,
    message: 'MCQ deleted successfully',
  });
});

// Bulk delete MCQs (admin only)
export const bulkDeleteMCQs = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { ids } = req.body;

  if (!Array.isArray(ids) || ids.length === 0) {
    throw new AppError('Please provide an array of MCQ IDs', 400);
  }

  const result = await MCQ.deleteMany({ _id: { $in: ids } });

  res.json({
    success: true,
    message: `${result.deletedCount} MCQs deleted successfully`,
    data: { deletedCount: result.deletedCount },
  });
});

// Preview CSV upload (admin only)
export const previewCSVUpload = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  if (!req.file) {
    throw new AppError('Please upload a CSV file', 400);
  }

  const { chapterId } = req.body;
  if (!chapterId) {
    throw new AppError('Chapter ID is required', 400);
  }

  // Parse CSV
  const rows = await csvUploadService.parseCSV(req.file.buffer);

  if (rows.length === 0) {
    throw new AppError('CSV file is empty or invalid', 400);
  }

  if (rows.length > CONSTANTS.MAX_UPLOAD_BATCH) {
    throw new AppError(
      `Maximum ${CONSTANTS.MAX_UPLOAD_BATCH} MCQs allowed per upload. Found: ${rows.length}`,
      400
    );
  }

  // Validate rows
  const preview = await csvUploadService.validateCSVUpload(rows, chapterId);

  res.json({
    success: true,
    data: preview,
  });
});

// Confirm CSV upload (admin only)
export const confirmCSVUpload = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { chapterId, validRows } = req.body;

  if (!chapterId) {
    throw new AppError('Chapter ID is required', 400);
  }

  if (!Array.isArray(validRows) || validRows.length === 0) {
    throw new AppError('No valid rows to upload', 400);
  }

  if (validRows.length > CONSTANTS.MAX_UPLOAD_BATCH) {
    throw new AppError(
      `Maximum ${CONSTANTS.MAX_UPLOAD_BATCH} MCQs allowed per upload`,
      400
    );
  }

  // Get chapter for bookId
  const chapter = await Chapter.findById(chapterId);
  if (!chapter) {
    throw new AppError('Chapter not found', 404);
  }

  // Get book
  const book = await Book.findOne({ subjectId: chapter.subjectId });

  // Save MCQs
  const result = await csvUploadService.saveMCQs(validRows, chapterId, book?._id.toString());

  res.json({
    success: true,
    message: `${result.saved} MCQs uploaded successfully`,
    data: {
      saved: result.saved,
      errors: result.errors,
    },
  });
});

// Download CSV template (admin only)
export const downloadCSVTemplate = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const template = csvUploadService.generateTemplate();

  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="mcq_template.csv"');
  res.send(template);
});

// Get MCQ counts for admin dashboard
export const getMCQCounts = asyncHandler(async (req: Request, res: Response): Promise<void> => {
  const { chapterId } = req.params;

  const chapter = await Chapter.findById(chapterId);
  if (!chapter) {
    throw new AppError('Chapter not found', 404);
  }

  const subject = await Subject.findById(chapter.subjectId);
  let subjectLimit = null;
  let subjectCount = null;

  if (subject) {
    if (subject.code === 'ENG') {
      subjectLimit = CONSTANTS.MAX_MCQS_ENGLISH;
      subjectCount = await MCQ.countDocuments({ subjectId: chapter.subjectId });
    } else if (subject.code === 'LR') {
      subjectLimit = CONSTANTS.MAX_MCQS_LOGICAL;
      subjectCount = await MCQ.countDocuments({ subjectId: chapter.subjectId });
    }
  }

  res.json({
    success: true,
    data: {
      chapter: {
        mcqCount: chapter.mcqCount,
        maxMcqs: chapter.maxMcqs,
        remainingSlots: chapter.maxMcqs - chapter.mcqCount,
      },
      subject: subjectLimit ? {
        mcqCount: subjectCount,
        maxMcqs: subjectLimit,
        remainingSlots: subjectLimit - (subjectCount || 0),
      } : null,
    },
  });
});
