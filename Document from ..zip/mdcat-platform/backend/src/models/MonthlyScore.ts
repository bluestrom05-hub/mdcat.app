import mongoose, { Schema } from 'mongoose';
import { IMonthlyScore } from '../types';

const monthlyScoreSchema = new Schema<IMonthlyScore>(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'User is required'],
    },
    month: {
      type: Number,
      required: [true, 'Month is required'],
      min: 1,
      max: 12,
    },
    year: {
      type: Number,
      required: [true, 'Year is required'],
    },
    score: {
      type: Number,
      default: 0,
    },
    correctAnswers: {
      type: Number,
      default: 0,
    },
    wrongAnswers: {
      type: Number,
      default: 0,
    },
    testsTaken: {
      type: Number,
      default: 0,
    },
    lastUpdated: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true,
  }
);

// Compound unique index - one score document per user per month
monthlyScoreSchema.index({ userId: 1, month: 1, year: 1 }, { unique: true });

// Index for leaderboard queries
monthlyScoreSchema.index({ month: 1, year: 1, score: -1 });
monthlyScoreSchema.index({ userId: 1 });

// Method to update score after a test
monthlyScoreSchema.methods.updateScore = async function (
  correctCount: number,
  wrongCount: number
): Promise<void> {
  this.score += correctCount - wrongCount;
  this.correctAnswers += correctCount;
  this.wrongAnswers += wrongCount;
  this.testsTaken += 1;
  this.lastUpdated = new Date();
  await this.save();
};

const MonthlyScore = mongoose.model<IMonthlyScore>('MonthlyScore', monthlyScoreSchema);

export default MonthlyScore;
