import mongoose, { Schema } from 'mongoose';
import { ITestSession } from '../types';

const testSessionSchema = new Schema<ITestSession>(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'User is required'],
    },
    pastPaperId: {
      type: Schema.Types.ObjectId,
      ref: 'PastPaper',
      default: null,
    },
    chapterId: {
      type: Schema.Types.ObjectId,
      ref: 'Chapter',
      default: null,
    },
    sessionType: {
      type: String,
      enum: ['practice', 'past_paper', 'competition'],
      required: [true, 'Session type is required'],
    },
    answers: {
      type: Map,
      of: String,
      default: new Map(),
    },
    startTime: {
      type: Date,
      default: Date.now,
    },
    endTime: {
      type: Date,
      default: null,
    },
    score: {
      type: Number,
      default: 0,
    },
    correctCount: {
      type: Number,
      default: 0,
    },
    wrongCount: {
      type: Number,
      default: 0,
    },
    isCompleted: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

// Indexes
testSessionSchema.index({ userId: 1, isCompleted: 1 });
testSessionSchema.index({ userId: 1, sessionType: 1 });
testSessionSchema.index({ pastPaperId: 1 });
testSessionSchema.index({ createdAt: -1 });

const TestSession = mongoose.model<ITestSession>('TestSession', testSessionSchema);

export default TestSession;
