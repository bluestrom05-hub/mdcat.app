import mongoose, { Schema } from 'mongoose';
import { IMCQ } from '../types';
import { CONSTANTS } from '../types';

const mcqSchema = new Schema<IMCQ>(
  {
    chapterId: {
      type: Schema.Types.ObjectId,
      ref: 'Chapter',
      required: [true, 'Chapter is required'],
    },
    subjectId: {
      type: Schema.Types.ObjectId,
      ref: 'Subject',
      required: [true, 'Subject is required'],
    },
    bookId: {
      type: Schema.Types.ObjectId,
      ref: 'Book',
      default: null,
    },
    question: {
      type: String,
      required: [true, 'Question is required'],
      trim: true,
    },
    optionA: {
      type: String,
      required: [true, 'Option A is required'],
      trim: true,
    },
    optionB: {
      type: String,
      required: [true, 'Option B is required'],
      trim: true,
    },
    optionC: {
      type: String,
      required: [true, 'Option C is required'],
      trim: true,
    },
    optionD: {
      type: String,
      required: [true, 'Option D is required'],
      trim: true,
    },
    correctAnswer: {
      type: String,
      enum: ['A', 'B', 'C', 'D'],
      required: [true, 'Correct answer is required'],
      uppercase: true,
    },
    explanation: {
      type: String,
      trim: true,
      default: '',
    },
  },
  {
    timestamps: true,
  }
);

// Indexes
mcqSchema.index({ chapterId: 1 });
mcqSchema.index({ subjectId: 1 });
mcqSchema.index({ bookId: 1 });
mcqSchema.index({ question: 'text' }); // For search functionality

// Compound index to prevent duplicate questions in same chapter
mcqSchema.index({ chapterId: 1, question: 1 }, { unique: true });

// Pre-save hook to validate MCQ limits
mcqSchema.pre('save', async function (next) {
  if (this.isNew) {
    try {
      const MCQ = mongoose.model('MCQ');
      const Chapter = mongoose.model('Chapter');
      const Subject = mongoose.model('Subject');
      
      // Get chapter info
      const chapter = await Chapter.findById(this.chapterId);
      if (!chapter) {
        throw new Error('Chapter not found');
      }
      
      // Check chapter MCQ limit
      if (chapter.mcqCount >= chapter.maxMcqs) {
        throw new Error(
          `Maximum ${chapter.maxMcqs} MCQs allowed per chapter. Current: ${chapter.mcqCount}`
        );
      }
      
      // Get subject info for special subjects
      const subject = await Subject.findById(this.subjectId);
      if (subject) {
        // Check English total limit
        if (subject.code === 'ENG') {
          const englishMcqCount = await MCQ.countDocuments({ subjectId: this.subjectId });
          if (englishMcqCount >= CONSTANTS.MAX_MCQS_ENGLISH) {
            throw new Error(
              `Maximum ${CONSTANTS.MAX_MCQS_ENGLISH} MCQs allowed for English`
            );
          }
        }
        
        // Check Logical Reasoning total limit
        if (subject.code === 'LR') {
          const logicalMcqCount = await MCQ.countDocuments({ subjectId: this.subjectId });
          if (logicalMcqCount >= CONSTANTS.MAX_MCQS_LOGICAL) {
            throw new Error(
              `Maximum ${CONSTANTS.MAX_MCQS_LOGICAL} MCQs allowed for Logical Reasoning`
            );
          }
        }
      }
      
      // Update chapter's MCQ count
      await Chapter.findByIdAndUpdate(this.chapterId, {
        $inc: { mcqCount: 1 },
      });
      
      // Update book's MCQ count if bookId exists
      if (this.bookId) {
        const Book = mongoose.model('Book');
        await Book.findByIdAndUpdate(this.bookId, {
          $inc: { mcqCount: 1 },
        });
      }
      
    } catch (error: any) {
      return next(error);
    }
  }
  next();
});

// Pre-remove hook to update counts
mcqSchema.pre('deleteOne', { document: true }, async function (next) {
  try {
    const Chapter = mongoose.model('Chapter');
    const Book = mongoose.model('Book');
    
    // Update chapter's MCQ count
    await Chapter.findByIdAndUpdate(this.chapterId, {
      $inc: { mcqCount: -1 },
    });
    
    // Update book's MCQ count if bookId exists
    if (this.bookId) {
      await Book.findByIdAndUpdate(this.bookId, {
        $inc: { mcqCount: -1 },
      });
    }
    
    next();
  } catch (error: any) {
    next(error);
  }
});

const MCQ = mongoose.model<IMCQ>('MCQ', mcqSchema);

export default MCQ;
