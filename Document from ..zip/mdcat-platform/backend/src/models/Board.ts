import mongoose, { Schema } from 'mongoose';
import { IBoard } from '../types';

const boardSchema = new Schema<IBoard>(
  {
    name: {
      type: String,
      required: [true, 'Board name is required'],
      trim: true,
      maxlength: [100, 'Board name cannot exceed 100 characters'],
    },
    code: {
      type: String,
      required: [true, 'Board code is required'],
      unique: true,
      uppercase: true,
      trim: true,
    },
    description: {
      type: String,
      trim: true,
      maxlength: [500, 'Description cannot exceed 500 characters'],
    },
  },
  {
    timestamps: true,
  }
);

// Indexes
boardSchema.index({ code: 1 });

const Board = mongoose.model<IBoard>('Board', boardSchema);

export default Board;
