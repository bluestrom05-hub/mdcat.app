import mongoose, { Schema } from 'mongoose';
import { IHallOfFame } from '../types';

const hallOfFameSchema = new Schema<IHallOfFame>(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'User is required'],
    },
    userName: {
      type: String,
      required: [true, 'User name is required'],
    },
    month: {
      type: Number,
      required: [true, 'Month is required'],
      min: 1,
      max: 12,
    },
    year: {
      type: Number,
      required: [true, 'Year is required'],
    },
    rank: {
      type: Number,
      required: [true, 'Rank is required'],
      min: 1,
      max: 3,
    },
    score: {
      type: Number,
      required: [true, 'Score is required'],
    },
  },
  {
    timestamps: true,
  }
);

// Compound index to prevent duplicate entries for same user in same month
hallOfFameSchema.index({ userId: 1, month: 1, year: 1 }, { unique: true });

// Index for querying winners by month/year
hallOfFameSchema.index({ month: 1, year: 1, rank: 1 });

const HallOfFame = mongoose.model<IHallOfFame>('HallOfFame', hallOfFameSchema);

export default HallOfFame;
