import mongoose, { Schema } from 'mongoose';
import { IBook } from '../types';

const bookSchema = new Schema<IBook>(
  {
    subjectId: {
      type: Schema.Types.ObjectId,
      ref: 'Subject',
      required: [true, 'Subject is required'],
    },
    boardId: {
      type: Schema.Types.ObjectId,
      ref: 'Board',
      required: [true, 'Board is required'],
    },
    class: {
      type: Number,
      required: [true, 'Class is required'],
      enum: [11, 12],
    },
    title: {
      type: String,
      required: [true, 'Book title is required'],
      trim: true,
    },
    chapterCount: {
      type: Number,
      default: 0,
      min: 0,
    },
    mcqCount: {
      type: Number,
      default: 0,
      min: 0,
    },
  },
  {
    timestamps: true,
  }
);

// Compound unique index to prevent duplicate books
bookSchema.index({ subjectId: 1, boardId: 1, class: 1 }, { unique: true });

// Additional indexes for queries
bookSchema.index({ subjectId: 1 });
bookSchema.index({ boardId: 1 });
bookSchema.index({ class: 1 });

// Auto-generate title if not provided
bookSchema.pre('save', async function (next) {
  if (!this.title) {
    try {
      const Subject = mongoose.model('Subject');
      const Board = mongoose.model('Board');
      
      const [subject, board] = await Promise.all([
        Subject.findById(this.subjectId),
        Board.findById(this.boardId),
      ]);
      
      if (subject && board) {
        this.title = `${subject.name} - ${board.name} - Class ${this.class}`;
      }
    } catch (error) {
      console.error('Error generating book title:', error);
    }
  }
  next();
});

const Book = mongoose.model<IBook>('Book', bookSchema);

export default Book;
