import mongoose, { Schema } from 'mongoose';
import { IPastPaper } from '../types';
import { CONSTANTS } from '../types';

const pastPaperSchema = new Schema<IPastPaper>(
  {
    title: {
      type: String,
      required: [true, 'Title is required'],
      trim: true,
      maxlength: [200, 'Title cannot exceed 200 characters'],
    },
    year: {
      type: Number,
      required: [true, 'Year is required'],
    },
    totalMarks: {
      type: Number,
      default: CONSTANTS.PAST_PAPER_MARKS,
    },
    duration: {
      type: Number,
      default: CONSTANTS.PAST_PAPER_DURATION, // in minutes
    },
    mcqs: [{
      type: Schema.Types.ObjectId,
      ref: 'MCQ',
    }],
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

// Indexes
pastPaperSchema.index({ year: 1 });
pastPaperSchema.index({ isActive: 1 });
pastPaperSchema.index({ year: 1, isActive: 1 });

const PastPaper = mongoose.model<IPastPaper>('PastPaper', pastPaperSchema);

export default PastPaper;
