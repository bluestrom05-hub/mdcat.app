import mongoose, { Schema } from 'mongoose';
import { ISubject } from '../types';

const subjectSchema = new Schema<ISubject>(
  {
    name: {
      type: String,
      required: [true, 'Subject name is required'],
      trim: true,
      maxlength: [100, 'Subject name cannot exceed 100 characters'],
    },
    code: {
      type: String,
      required: [true, 'Subject code is required'],
      unique: true,
      uppercase: true,
      trim: true,
    },
    type: {
      type: String,
      enum: ['science', 'english', 'logical'],
      required: [true, 'Subject type is required'],
    },
    description: {
      type: String,
      trim: true,
      maxlength: [500, 'Description cannot exceed 500 characters'],
    },
  },
  {
    timestamps: true,
  }
);

// Indexes
subjectSchema.index({ code: 1 });
subjectSchema.index({ type: 1 });

const Subject = mongoose.model<ISubject>('Subject', subjectSchema);

export default Subject;
