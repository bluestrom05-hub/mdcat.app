import mongoose, { Schema } from 'mongoose';
import { IChapter } from '../types';
import { CONSTANTS } from '../types';

const chapterSchema = new Schema<IChapter>(
  {
    bookId: {
      type: Schema.Types.ObjectId,
      ref: 'Book',
      required: [true, 'Book is required'],
    },
    subjectId: {
      type: Schema.Types.ObjectId,
      ref: 'Subject',
      required: [true, 'Subject is required'],
    },
    name: {
      type: String,
      required: [true, 'Chapter name is required'],
      trim: true,
      maxlength: [200, 'Chapter name cannot exceed 200 characters'],
    },
    number: {
      type: Number,
      required: [true, 'Chapter number is required'],
      min: 1,
    },
    mcqCount: {
      type: Number,
      default: 0,
      min: 0,
    },
    maxMcqs: {
      type: Number,
      default: CONSTANTS.MAX_MCQS_PER_CHAPTER,
      max: CONSTANTS.MAX_MCQS_PER_CHAPTER,
    },
  },
  {
    timestamps: true,
  }
);

// Indexes
chapterSchema.index({ bookId: 1, number: 1 }, { unique: true });
chapterSchema.index({ subjectId: 1 });
chapterSchema.index({ bookId: 1 });

// Pre-save hook to validate chapter limit per book
chapterSchema.pre('save', async function (next) {
  if (this.isNew) {
    try {
      const Chapter = mongoose.model('Chapter');
      const Book = mongoose.model('Book');
      
      // Check if book has reached max chapters
      const chapterCount = await Chapter.countDocuments({ bookId: this.bookId });
      
      if (chapterCount >= CONSTANTS.MAX_CHAPTERS_PER_BOOK) {
        throw new Error(`Maximum ${CONSTANTS.MAX_CHAPTERS_PER_BOOK} chapters allowed per book`);
      }
      
      // Update book's chapter count
      await Book.findByIdAndUpdate(this.bookId, {
        $inc: { chapterCount: 1 },
      });
      
    } catch (error: any) {
      return next(error);
    }
  }
  next();
});

// Pre-remove hook to update book's chapter count
chapterSchema.pre('deleteOne', { document: true }, async function (next) {
  try {
    const Book = mongoose.model('Book');
    await Book.findByIdAndUpdate(this.bookId, {
      $inc: { chapterCount: -1 },
    });
    next();
  } catch (error: any) {
    next(error);
  }
});

const Chapter = mongoose.model<IChapter>('Chapter', chapterSchema);

export default Chapter;
