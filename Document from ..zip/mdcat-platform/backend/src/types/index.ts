import { Document, Types } from 'mongoose';

// User Types
export interface IUser extends Document {
  _id: Types.ObjectId;
  email: string;
  password: string;
  name: string;
  role: 'user' | 'admin';
  isPremium: boolean;
  premiumSince?: Date;
  createdAt: Date;
  updatedAt: Date;
  comparePassword(candidatePassword: string): Promise<boolean>;
}

export interface IUserPayload {
  userId: string;
  email: string;
  role: string;
}

// Subject Types
export interface ISubject extends Document {
  _id: Types.ObjectId;
  name: string;
  code: string;
  type: 'science' | 'english' | 'logical';
  description?: string;
  createdAt: Date;
  updatedAt: Date;
}

// Board Types
export interface IBoard extends Document {
  _id: Types.ObjectId;
  name: string;
  code: string;
  description?: string;
  createdAt: Date;
  updatedAt: Date;
}

// Book Types
export interface IBook extends Document {
  _id: Types.ObjectId;
  subjectId: Types.ObjectId;
  boardId: Types.ObjectId;
  class: number;
  title: string;
  chapterCount: number;
  mcqCount: number;
  createdAt: Date;
  updatedAt: Date;
}

// Chapter Types
export interface IChapter extends Document {
  _id: Types.ObjectId;
  bookId: Types.ObjectId;
  subjectId: Types.ObjectId;
  name: string;
  number: number;
  mcqCount: number;
  maxMcqs: number;
  createdAt: Date;
  updatedAt: Date;
}

// MCQ Types
export interface IMCQ extends Document {
  _id: Types.ObjectId;
  chapterId: Types.ObjectId;
  subjectId: Types.ObjectId;
  bookId?: Types.ObjectId;
  question: string;
  optionA: string;
  optionB: string;
  optionC: string;
  optionD: string;
  correctAnswer: 'A' | 'B' | 'C' | 'D';
  explanation?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface IMCQInput {
  question: string;
  optionA: string;
  optionB: string;
  optionC: string;
  optionD: string;
  correctAnswer: string;
  explanation?: string;
}

export interface ICSVRow {
  chapter?: string;
  question: string;
  optionA: string;
  optionB: string;
  optionC: string;
  optionD: string;
  correctAnswer: string;
  explanation?: string;
  rowNumber: number;
}

export interface ICSVValidationResult {
  valid: boolean;
  row: ICSVRow;
  errors: string[];
  isDuplicate?: boolean;
}

// Monthly Score Types
export interface IMonthlyScore extends Document {
  _id: Types.ObjectId;
  userId: Types.ObjectId;
  month: number;
  year: number;
  score: number;
  correctAnswers: number;
  wrongAnswers: number;
  testsTaken: number;
  lastUpdated: Date;
  createdAt: Date;
  updatedAt: Date;
}

// Hall of Fame Types
export interface IHallOfFame extends Document {
  _id: Types.ObjectId;
  userId: Types.ObjectId;
  userName: string;
  month: number;
  year: number;
  rank: number;
  score: number;
  createdAt: Date;
}

// Past Paper Types
export interface IPastPaper extends Document {
  _id: Types.ObjectId;
  title: string;
  year: number;
  totalMarks: number;
  duration: number;
  mcqs: Types.ObjectId[];
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// Test Session Types
export interface ITestSession extends Document {
  _id: Types.ObjectId;
  userId: Types.ObjectId;
  pastPaperId?: Types.ObjectId;
  chapterId?: Types.ObjectId;
  sessionType: 'practice' | 'past_paper' | 'competition';
  answers: Map<string, string>;
  startTime: Date;
  endTime?: Date;
  score: number;
  correctCount: number;
  wrongCount: number;
  isCompleted: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// Leaderboard Entry Types
export interface ILeaderboardEntry {
  rank: number;
  userId: string;
  name: string;
  score: number;
  isPremium: boolean;
}

// API Response Types
export interface ApiResponse<T = any> {
  success: boolean;
  message: string;
  data?: T;
  errors?: string[];
  meta?: {
    page?: number;
    limit?: number;
    total?: number;
    totalPages?: number;
  };
}

// CSV Upload Types
export interface ICSVUploadPreview {
  validRows: ICSVValidationResult[];
  invalidRows: ICSVValidationResult[];
  totalRows: number;
  validCount: number;
  invalidCount: number;
  remainingSlots: number;
}

// Device Capability Types
export interface IDeviceCapability {
  tier: 'low' | 'mid' | 'high';
  supportsWebGL: boolean;
  supports3D: boolean;
  maxAnimations: number;
}

// Constants
export const CONSTANTS = {
  MAX_CHAPTERS_PER_BOOK: 15,
  MAX_MCQS_PER_CHAPTER: 280,
  MAX_MCQS_ENGLISH: 500,
  MAX_MCQS_LOGICAL: 300,
  CSV_BATCH_SIZE: 200,
  MAX_UPLOAD_BATCH: 250,
  PAST_PAPER_MARKS: 180,
  PAST_PAPER_DURATION: 180,
  PREMIUM_PRICE: 2500,
  MONTHLY_WINNERS_COUNT: 3,
  LEADERBOARD_PAGE_SIZE: 50,
  RATE_LIMIT_WINDOW: 15 * 60 * 1000, // 15 minutes
  RATE_LIMIT_MAX: 100,
  UPLOAD_RATE_LIMIT_MAX: 10,
} as const;
