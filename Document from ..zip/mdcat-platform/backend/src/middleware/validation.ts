import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';

// Validation middleware factory
export const validate = (schema: Joi.ObjectSchema) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    const { error } = schema.validate(req.body, {
      abortEarly: false,
      stripUnknown: true,
    });

    if (error) {
      const errors = error.details.map((detail) => detail.message);
      res.status(400).json({
        success: false,
        message: 'Validation error',
        errors,
      });
      return;
    }

    next();
  };
};

// Validation schemas
export const schemas = {
  // Auth schemas
  register: Joi.object({
    name: Joi.string().min(2).max(50).required()
      .messages({
        'string.min': 'Name must be at least 2 characters',
        'string.max': 'Name cannot exceed 50 characters',
        'any.required': 'Name is required',
      }),
    email: Joi.string().email().required()
      .messages({
        'string.email': 'Please enter a valid email',
        'any.required': 'Email is required',
      }),
    password: Joi.string().min(6).required()
      .messages({
        'string.min': 'Password must be at least 6 characters',
        'any.required': 'Password is required',
      }),
  }),

  login: Joi.object({
    email: Joi.string().email().required()
      .messages({
        'string.email': 'Please enter a valid email',
        'any.required': 'Email is required',
      }),
    password: Joi.string().required()
      .messages({
        'any.required': 'Password is required',
      }),
  }),

  // Subject schemas
  createSubject: Joi.object({
    name: Joi.string().min(2).max(100).required(),
    code: Joi.string().uppercase().min(2).max(10).required(),
    type: Joi.string().valid('science', 'english', 'logical').required(),
    description: Joi.string().max(500).optional(),
  }),

  // Board schemas
  createBoard: Joi.object({
    name: Joi.string().min(2).max(100).required(),
    code: Joi.string().uppercase().min(2).max(10).required(),
    description: Joi.string().max(500).optional(),
  }),

  // Book schemas
  createBook: Joi.object({
    subjectId: Joi.string().hex().length(24).required()
      .messages({
        'string.hex': 'Invalid subject ID',
        'string.length': 'Invalid subject ID',
      }),
    boardId: Joi.string().hex().length(24).required()
      .messages({
        'string.hex': 'Invalid board ID',
        'string.length': 'Invalid board ID',
      }),
    class: Joi.number().valid(11, 12).required(),
  }),

  // Chapter schemas
  createChapter: Joi.object({
    bookId: Joi.string().hex().length(24).required(),
    name: Joi.string().min(2).max(200).required(),
    number: Joi.number().integer().min(1).required(),
  }),

  // MCQ schemas
  createMCQ: Joi.object({
    chapterId: Joi.string().hex().length(24).required(),
    question: Joi.string().min(5).required()
      .messages({
        'string.min': 'Question must be at least 5 characters',
        'any.required': 'Question is required',
      }),
    optionA: Joi.string().min(1).required(),
    optionB: Joi.string().min(1).required(),
    optionC: Joi.string().min(1).required(),
    optionD: Joi.string().min(1).required(),
    correctAnswer: Joi.string().valid('A', 'B', 'C', 'D').uppercase().required()
      .messages({
        'any.only': 'Correct answer must be A, B, C, or D',
        'any.required': 'Correct answer is required',
      }),
    explanation: Joi.string().optional(),
  }),

  // Test session schemas
  submitTest: Joi.object({
    sessionId: Joi.string().hex().length(24).required(),
    answers: Joi.object().pattern(Joi.string(), Joi.string().valid('A', 'B', 'C', 'D')).required(),
  }),

  // Past paper schemas
  createPastPaper: Joi.object({
    title: Joi.string().min(5).max(200).required(),
    year: Joi.number().integer().min(2000).max(2100).required(),
    mcqIds: Joi.array().items(Joi.string().hex().length(24)).min(1).required(),
  }),
};
