import csv from 'csv-parser';
import { Readable } from 'stream';
import { ICSVRow, ICSVValidationResult, ICSVUploadPreview, CONSTANTS } from '../types';
import { MCQ, Chapter, Subject } from '../models';

class CSVUploadService {
  /**
   * Parse CSV buffer and return rows
   */
  async parseCSV(buffer: Buffer): Promise<ICSVRow[]> {
    return new Promise((resolve, reject) => {
      const rows: ICSVRow[] = [];
      let rowNumber = 0;

      const stream = Readable.from(buffer.toString());

      stream
        .pipe(csv({
          mapHeaders: ({ header }) => header.trim().toLowerCase(),
          mapValues: ({ value }) => value.trim(),
        }))
        .on('data', (data) => {
          rowNumber++;
          rows.push({
            ...data,
            rowNumber,
          });
        })
        .on('end', () => resolve(rows))
        .on('error', (error) => reject(error));
    });
  }

  /**
   * Validate a single CSV row
   */
  async validateRow(
    row: ICSVRow,
    chapterId: string,
    existingQuestions: Set<string>
  ): Promise<ICSVValidationResult> {
    const errors: string[] = [];

    // Required fields validation
    if (!row.question || row.question.trim().length < 5) {
      errors.push('Question is required and must be at least 5 characters');
    }

    if (!row.optionA?.trim()) errors.push('Option A is required');
    if (!row.optionB?.trim()) errors.push('Option B is required');
    if (!row.optionC?.trim()) errors.push('Option C is required');
    if (!row.optionD?.trim()) errors.push('Option D is required');

    // Correct answer validation
    const validAnswers = ['A', 'B', 'C', 'D'];
    const correctAnswer = row.correctAnswer?.toUpperCase().trim();
    if (!correctAnswer || !validAnswers.includes(correctAnswer)) {
      errors.push('Correct answer must be A, B, C, or D');
    }

    // Check for duplicate within CSV
    const questionKey = row.question?.toLowerCase().trim();
    if (questionKey && existingQuestions.has(questionKey)) {
      errors.push('Duplicate question within CSV file');
    }

    // Check for duplicate in database (only if basic validation passes)
    if (errors.length === 0 && questionKey) {
      const existingMCQ = await MCQ.findOne({
        chapterId,
        question: { $regex: new RegExp(`^${row.question.trim()}$`, 'i') },
      });

      if (existingMCQ) {
        errors.push('Question already exists in this chapter');
      }
    }

    return {
      valid: errors.length === 0,
      row,
      errors,
      isDuplicate: errors.some(e => e.includes('Duplicate')),
    };
  }

  /**
   * Validate all CSV rows and return preview
   */
  async validateCSVUpload(
    rows: ICSVRow[],
    chapterId: string
  ): Promise<ICSVUploadPreview> {
    // Get chapter info
    const chapter = await Chapter.findById(chapterId);
    if (!chapter) {
      throw new Error('Chapter not found');
    }

    // Get subject info
    const subject = await Subject.findById(chapter.subjectId);
    if (!subject) {
      throw new Error('Subject not found');
    }

    // Calculate remaining slots
    let maxAllowed: number;
    if (subject.code === 'ENG') {
      const englishMcqCount = await MCQ.countDocuments({ subjectId: chapter.subjectId });
      maxAllowed = CONSTANTS.MAX_MCQS_ENGLISH - englishMcqCount;
    } else if (subject.code === 'LR') {
      const logicalMcqCount = await MCQ.countDocuments({ subjectId: chapter.subjectId });
      maxAllowed = CONSTANTS.MAX_MCQS_LOGICAL - logicalMcqCount;
    } else {
      maxAllowed = chapter.maxMcqs - chapter.mcqCount;
    }

    // Check if upload exceeds batch limit
    if (rows.length > CONSTANTS.MAX_UPLOAD_BATCH) {
      throw new Error(
        `Maximum ${CONSTANTS.MAX_UPLOAD_BATCH} MCQs allowed per upload. Received: ${rows.length}`
      );
    }

    // Check if upload would exceed remaining slots
    if (rows.length > maxAllowed) {
      throw new Error(
        `Upload would exceed remaining slots. Remaining: ${maxAllowed}, Received: ${rows.length}`
      );
    }

    const validRows: ICSVValidationResult[] = [];
    const invalidRows: ICSVValidationResult[] = [];
    const seenQuestions = new Set<string>();

    // Process in chunks to avoid memory issues
    const chunkSize = CONSTANTS.CSV_BATCH_SIZE;
    for (let i = 0; i < rows.length; i += chunkSize) {
      const chunk = rows.slice(i, i + chunkSize);
      
      for (const row of chunk) {
        const result = await this.validateRow(row, chapterId, seenQuestions);
        
        if (result.valid) {
          validRows.push(result);
          seenQuestions.add(row.question.toLowerCase().trim());
        } else {
          invalidRows.push(result);
        }
      }
    }

    return {
      validRows,
      invalidRows,
      totalRows: rows.length,
      validCount: validRows.length,
      invalidCount: invalidRows.length,
      remainingSlots: maxAllowed - validRows.length,
    };
  }

  /**
   * Save valid MCQs to database
   */
  async saveMCQs(
    validRows: ICSVValidationResult[],
    chapterId: string,
    bookId?: string
  ): Promise<{ saved: number; errors: string[] }> {
    const chapter = await Chapter.findById(chapterId);
    if (!chapter) {
      throw new Error('Chapter not found');
    }

    const errors: string[] = [];
    let saved = 0;

    // Process in batches
    const batchSize = 50;
    for (let i = 0; i < validRows.length; i += batchSize) {
      const batch = validRows.slice(i, i + batchSize);
      
      for (const { row } of batch) {
        try {
          await MCQ.create({
            chapterId,
            subjectId: chapter.subjectId,
            bookId,
            question: row.question.trim(),
            optionA: row.optionA.trim(),
            optionB: row.optionB.trim(),
            optionC: row.optionC.trim(),
            optionD: row.optionD.trim(),
            correctAnswer: row.correctAnswer.toUpperCase().trim(),
            explanation: row.explanation?.trim() || '',
          });
          saved++;
        } catch (error: any) {
          errors.push(`Row ${row.rowNumber}: ${error.message}`);
        }
      }
    }

    return { saved, errors };
  }

  /**
   * Generate CSV template
   */
  generateTemplate(): string {
    const headers = ['question', 'optionA', 'optionB', 'optionC', 'optionD', 'correctAnswer', 'explanation'];
    const exampleRow = [
      'What is the capital of Pakistan?',
      'Lahore',
      'Karachi',
      'Islamabad',
      'Peshawar',
      'C',
      'Islamabad is the capital city of Pakistan',
    ];
    
    return [headers.join(','), exampleRow.join(',')].join('\n');
  }
}

export default new CSVUploadService();
