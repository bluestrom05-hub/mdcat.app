import { MCQ, TestSession, MonthlyScore } from '../models';
import leaderboardService from './leaderboardService';

export interface ITestResult {
  score: number;
  correctCount: number;
  wrongCount: number;
  unansweredCount: number;
  percentage: number;
  timeTaken: number;
}

class ScoringService {
  /**
   * Calculate test result
   * Scoring: +1 for correct, -1 for wrong, 0 for unanswered
   */
  async calculateResult(
    sessionId: string,
    answers: Map<string, string> | Record<string, string>
  ): Promise<ITestResult> {
    const session = await TestSession.findById(sessionId);
    if (!session) {
      throw new Error('Test session not found');
    }

    // Get all MCQs for this session
    let mcqIds: string[] = [];
    if (session.pastPaperId) {
      const PastPaper = (await import('../models/PastPaper')).default;
      const pastPaper = await PastPaper.findById(session.pastPaperId);
      if (pastPaper) {
        mcqIds = pastPaper.mcqs.map((id) => id.toString());
      }
    } else if (session.chapterId) {
      const chapterMcqs = await MCQ.find({ chapterId: session.chapterId });
      mcqIds = chapterMcqs.map((mcq) => mcq._id.toString());
    }

    // Convert answers to Map if needed
    const answersMap = answers instanceof Map 
      ? answers 
      : new Map(Object.entries(answers));

    // Calculate score
    let correctCount = 0;
    let wrongCount = 0;
    let unansweredCount = 0;

    for (const mcqId of mcqIds) {
      const userAnswer = answersMap.get(mcqId);
      
      if (!userAnswer) {
        unansweredCount++;
        continue;
      }

      const mcq = await MCQ.findById(mcqId);
      if (!mcq) continue;

      if (userAnswer.toUpperCase() === mcq.correctAnswer) {
        correctCount++;
      } else {
        wrongCount++;
      }
    }

    // Calculate score: +1 for correct, -1 for wrong
    const score = correctCount - wrongCount;
    const totalQuestions = mcqIds.length;
    const percentage = totalQuestions > 0 
      ? Math.round((correctCount / totalQuestions) * 100) 
      : 0;

    // Calculate time taken
    const endTime = new Date();
    const timeTaken = session.startTime 
      ? Math.floor((endTime.getTime() - session.startTime.getTime()) / 1000) 
      : 0;

    return {
      score,
      correctCount,
      wrongCount,
      unansweredCount,
      percentage,
      timeTaken,
    };
  }

  /**
   * Submit test and update all related data
   */
  async submitTest(
    sessionId: string,
    answers: Map<string, string> | Record<string, string>,
    userId: string
  ): Promise<ITestResult> {
    const session = await TestSession.findById(sessionId);
    if (!session) {
      throw new Error('Test session not found');
    }

    if (session.isCompleted) {
      throw new Error('Test already submitted');
    }

    // Calculate result
    const result = await this.calculateResult(sessionId, answers);

    // Update session
    const answersMap = answers instanceof Map 
      ? answers 
      : new Map(Object.entries(answers));

    session.answers = answersMap;
    session.score = result.score;
    session.correctCount = result.correctCount;
    session.wrongCount = result.wrongCount;
    session.isCompleted = true;
    session.endTime = new Date();
    await session.save();

    // Update monthly score for competition
    if (session.sessionType === 'competition' || session.sessionType === 'past_paper') {
      const now = new Date();
      await leaderboardService.updateScore(
        userId,
        now.getMonth() + 1,
        now.getFullYear(),
        result.correctCount,
        result.wrongCount
      );
    }

    return result;
  }

  /**
   * Auto-submit test when time expires
   */
  async autoSubmit(sessionId: string, userId: string): Promise<ITestResult> {
    const session = await TestSession.findById(sessionId);
    if (!session) {
      throw new Error('Test session not found');
    }

    if (session.isCompleted) {
      throw new Error('Test already submitted');
    }

    // Submit with current answers (may be empty)
    return this.submitTest(sessionId, session.answers, userId);
  }

  /**
   * Get user's test history
   */
  async getTestHistory(
    userId: string,
    page: number = 1,
    limit: number = 10
  ): Promise<{ sessions: any[]; total: number }> {
    const skip = (page - 1) * limit;

    const [sessions, total] = await Promise.all([
      TestSession.find({ userId, isCompleted: true })
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .populate('pastPaperId', 'title year')
        .populate('chapterId', 'name')
        .lean(),
      TestSession.countDocuments({ userId, isCompleted: true }),
    ]);

    return { sessions, total };
  }
}

export default new ScoringService();
