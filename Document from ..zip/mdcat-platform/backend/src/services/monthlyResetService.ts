import cron from 'node-cron';
import { MonthlyScore, HallOfFame, User } from '../models';
import leaderboardService from './leaderboardService';
import { CONSTANTS } from '../types';

class MonthlyResetService {
  private isRunning: boolean = false;

  /**
   * Initialize the monthly reset cron job
   * Runs at 00:00 on the 1st of every month
   */
  initialize(): void {
    // Schedule: minute hour day month day-of-week
    // 0 0 1 * * = At 00:00 on day-of-month 1
    cron.schedule('0 0 1 * *', async () => {
      console.log('Running monthly reset job...');
      await this.performReset();
    }, {
      timezone: 'Asia/Karachi', // Pakistan timezone
    });

    console.log('Monthly reset cron job initialized');
  }

  /**
   * Perform the monthly reset
   */
  async performReset(): Promise<void> {
    if (this.isRunning) {
      console.log('Reset already in progress, skipping...');
      return;
    }

    this.isRunning = true;

    try {
      // Get previous month
      const now = new Date();
      const previousMonth = now.getMonth() === 0 ? 12 : now.getMonth();
      const previousYear = now.getMonth() === 0 ? now.getFullYear() - 1 : now.getFullYear();

      console.log(`Processing reset for ${previousMonth}/${previousYear}`);

      // Get top 3 winners
      const topScores = await MonthlyScore.find({
        month: previousMonth,
        year: previousYear,
      })
        .sort({ score: -1, lastUpdated: 1 })
        .limit(CONSTANTS.MONTHLY_WINNERS_COUNT)
        .populate('userId', 'name');

      // Save winners to Hall of Fame and grant premium
      for (let i = 0; i < topScores.length; i++) {
        const score = topScores[i];
        const userId = (score.userId as any)._id.toString();
        const userName = (score.userId as any).name;

        // Add to Hall of Fame
        await HallOfFame.create({
          userId,
          userName,
          month: previousMonth,
          year: previousYear,
          rank: i + 1,
          score: score.score,
        });

        // Grant premium status
        await User.findByIdAndUpdate(userId, {
          isPremium: true,
          premiumSince: new Date(),
        });

        console.log(`Winner ${i + 1}: ${userName} with score ${score.score}`);
      }

      // Clear leaderboard cache for the new month
      await leaderboardService.invalidateCache(now.getMonth() + 1, now.getFullYear());

      console.log('Monthly reset completed successfully');
    } catch (error) {
      console.error('Error during monthly reset:', error);
    } finally {
      this.isRunning = false;
    }
  }

  /**
   * Manually trigger reset (for admin/testing)
   */
  async manualReset(month?: number, year?: number): Promise<void> {
    if (this.isRunning) {
      throw new Error('Reset already in progress');
    }

    this.isRunning = true;

    try {
      const now = new Date();
      const targetMonth = month || (now.getMonth() === 0 ? 12 : now.getMonth());
      const targetYear = year || (now.getMonth() === 0 ? now.getFullYear() - 1 : now.getFullYear());

      console.log(`Manual reset for ${targetMonth}/${targetYear}`);

      // Get top 3 winners
      const topScores = await MonthlyScore.find({
        month: targetMonth,
        year: targetYear,
      })
        .sort({ score: -1, lastUpdated: 1 })
        .limit(CONSTANTS.MONTHLY_WINNERS_COUNT)
        .populate('userId', 'name');

      // Save winners to Hall of Fame
      for (let i = 0; i < topScores.length; i++) {
        const score = topScores[i];
        const userId = (score.userId as any)._id.toString();
        const userName = (score.userId as any).name;

        // Check if already in Hall of Fame
        const existing = await HallOfFame.findOne({
          userId,
          month: targetMonth,
          year: targetYear,
        });

        if (!existing) {
          await HallOfFame.create({
            userId,
            userName,
            month: targetMonth,
            year: targetYear,
            rank: i + 1,
            score: score.score,
          });

          // Grant premium
          await User.findByIdAndUpdate(userId, {
            isPremium: true,
            premiumSince: new Date(),
          });
        }

        console.log(`Winner ${i + 1}: ${userName} with score ${score.score}`);
      }

      console.log('Manual reset completed');
    } catch (error) {
      console.error('Error during manual reset:', error);
      throw error;
    } finally {
      this.isRunning = false;
    }
  }

  /**
   * Get Hall of Fame entries
   */
  async getHallOfFame(
    month?: number,
    year?: number,
    page: number = 1,
    limit: number = 10
  ): Promise<{ entries: any[]; total: number }> {
    const query: any = {};
    if (month) query.month = month;
    if (year) query.year = year;

    const skip = (page - 1) * limit;

    const [entries, total] = await Promise.all([
      HallOfFame.find(query)
        .sort({ year: -1, month: -1, rank: 1 })
        .skip(skip)
        .limit(limit)
        .populate('userId', 'name isPremium')
        .lean(),
      HallOfFame.countDocuments(query),
    ]);

    return { entries, total };
  }

  /**
   * Check if reset is running
   */
  isResetRunning(): boolean {
    return this.isRunning;
  }
}

export default new MonthlyResetService();
