import RedisClient, { CACHE_KEYS, CACHE_TTL } from '../config/redis';
import { MonthlyScore, User } from '../models';
import { ILeaderboardEntry } from '../types';

class LeaderboardService {
  private redis = RedisClient.getInstance();

  /**
   * Get leaderboard for a specific month
   */
  async getLeaderboard(
    month: number,
    year: number,
    page: number = 1,
    limit: number = 50
  ): Promise<{ entries: ILeaderboardEntry[]; total: number }> {
    const cacheKey = CACHE_KEYS.LEADERBOARD(month, year);
    
    // Try to get from cache
    try {
      const cached = await this.redis.get(cacheKey);
      if (cached) {
        const allEntries: ILeaderboardEntry[] = JSON.parse(cached);
        const start = (page - 1) * limit;
        const end = start + limit;
        return {
          entries: allEntries.slice(start, end),
          total: allEntries.length,
        };
      }
    } catch (error) {
      console.error('Redis cache error:', error);
    }

    // Fetch from database
    const scores = await MonthlyScore.find({ month, year })
      .sort({ score: -1, lastUpdated: 1 })
      .populate('userId', 'name isPremium')
      .lean();

    const entries: ILeaderboardEntry[] = scores.map((score, index) => ({
      rank: index + 1,
      userId: (score.userId as any)._id.toString(),
      name: (score.userId as any).name,
      score: score.score,
      isPremium: (score.userId as any).isPremium,
    }));

    // Cache the full leaderboard
    try {
      await this.redis.setex(
        cacheKey,
        CACHE_TTL.LEADERBOARD,
        JSON.stringify(entries)
      );
    } catch (error) {
      console.error('Redis cache set error:', error);
    }

    const start = (page - 1) * limit;
    const end = start + limit;
    return {
      entries: entries.slice(start, end),
      total: entries.length,
    };
  }

  /**
   * Get user's rank
   */
  async getUserRank(
    userId: string,
    month: number,
    year: number
  ): Promise<{ rank: number; score: number } | null> {
    const cacheKey = CACHE_KEYS.USER_RANK(userId, month, year);

    // Try cache first
    try {
      const cached = await this.redis.get(cacheKey);
      if (cached) {
        return JSON.parse(cached);
      }
    } catch (error) {
      console.error('Redis cache error:', error);
    }

    // Get user's score
    const userScore = await MonthlyScore.findOne({ userId, month, year });
    if (!userScore) {
      return null;
    }

    // Count users with higher scores
    const higherScores = await MonthlyScore.countDocuments({
      month,
      year,
      $or: [
        { score: { $gt: userScore.score } },
        {
          score: userScore.score,
          lastUpdated: { $lt: userScore.lastUpdated },
        },
      ],
    });

    const result = {
      rank: higherScores + 1,
      score: userScore.score,
    };

    // Cache the result
    try {
      await this.redis.setex(
        cacheKey,
        CACHE_TTL.USER_RANK,
        JSON.stringify(result)
      );
    } catch (error) {
      console.error('Redis cache set error:', error);
    }

    return result;
  }

  /**
   * Get top 3 performers (for homepage)
   */
  async getTopPerformers(
    month: number,
    year: number
  ): Promise<ILeaderboardEntry[]> {
    const cacheKey = CACHE_KEYS.TOP_PERFORMERS(month, year);

    // Try cache
    try {
      const cached = await this.redis.get(cacheKey);
      if (cached) {
        return JSON.parse(cached);
      }
    } catch (error) {
      console.error('Redis cache error:', error);
    }

    // Get top 3 from database
    const scores = await MonthlyScore.find({ month, year })
      .sort({ score: -1, lastUpdated: 1 })
      .limit(3)
      .populate('userId', 'name isPremium')
      .lean();

    const entries: ILeaderboardEntry[] = scores.map((score, index) => ({
      rank: index + 1,
      userId: (score.userId as any)._id.toString(),
      name: (score.userId as any).name,
      score: score.score,
      isPremium: (score.userId as any).isPremium,
    }));

    // Cache
    try {
      await this.redis.setex(
        cacheKey,
        CACHE_TTL.TOP_PERFORMERS,
        JSON.stringify(entries)
      );
    } catch (error) {
      console.error('Redis cache set error:', error);
    }

    return entries;
  }

  /**
   * Invalidate leaderboard cache
   */
  async invalidateCache(month: number, year: number): Promise<void> {
    const keys = [
      CACHE_KEYS.LEADERBOARD(month, year),
      CACHE_KEYS.TOP_PERFORMERS(month, year),
    ];

    try {
      await this.redis.del(...keys);
    } catch (error) {
      console.error('Redis cache invalidation error:', error);
    }
  }

  /**
   * Invalidate user rank cache
   */
  async invalidateUserRank(
    userId: string,
    month: number,
    year: number
  ): Promise<void> {
    try {
      await this.redis.del(CACHE_KEYS.USER_RANK(userId, month, year));
    } catch (error) {
      console.error('Redis cache invalidation error:', error);
    }
  }

  /**
   * Update score and recalculate rank
   */
  async updateScore(
    userId: string,
    month: number,
    year: number,
    correctCount: number,
    wrongCount: number
  ): Promise<void> {
    // Update score in database
    await MonthlyScore.findOneAndUpdate(
      { userId, month, year },
      {
        $inc: {
          score: correctCount - wrongCount,
          correctAnswers: correctCount,
          wrongAnswers: wrongCount,
          testsTaken: 1,
        },
        $set: { lastUpdated: new Date() },
      },
      { upsert: true, new: true }
    );

    // Invalidate caches
    await this.invalidateCache(month, year);
    await this.invalidateUserRank(userId, month, year);
  }
}

export default new LeaderboardService();
