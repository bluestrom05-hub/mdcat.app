import Redis from 'ioredis';

class RedisClient {
  private static instance: Redis;
  private static isConnected: boolean = false;

  static getInstance(): Redis {
    if (!RedisClient.instance) {
      const redisURL = process.env.REDIS_URL || 'redis://localhost:6379';
      
      RedisClient.instance = new Redis(redisURL, {
        maxRetriesPerRequest: 3,
        enableReadyCheck: true,
        retryStrategy: (times) => {
          if (times > 3) {
            console.error('Redis connection failed after 3 retries');
            return null;
          }
          return Math.min(times * 100, 3000);
        },
      });

      RedisClient.instance.on('connect', () => {
        console.log('Redis Connected Successfully');
        RedisClient.isConnected = true;
      });

      RedisClient.instance.on('error', (err) => {
        console.error('Redis connection error:', err);
        RedisClient.isConnected = false;
      });

      RedisClient.instance.on('close', () => {
        console.log('Redis connection closed');
        RedisClient.isConnected = false;
      });
    }

    return RedisClient.instance;
  }

  static async disconnect(): Promise<void> {
    if (RedisClient.instance) {
      await RedisClient.instance.quit();
      RedisClient.isConnected = false;
    }
  }

  static isReady(): boolean {
    return RedisClient.isConnected;
  }
}

// Leaderboard cache keys
export const CACHE_KEYS = {
  LEADERBOARD: (month: number, year: number) => `leaderboard:${year}:${month}`,
  USER_RANK: (userId: string, month: number, year: number) => `user_rank:${userId}:${year}:${month}`,
  TOP_PERFORMERS: (month: number, year: number) => `top_performers:${year}:${month}`,
  MCQ_COUNT: (chapterId: string) => `mcq_count:${chapterId}`,
  CHAPTER_COUNT: (bookId: string) => `chapter_count:${bookId}`,
};

// Cache TTL in seconds
export const CACHE_TTL = {
  LEADERBOARD: 300, // 5 minutes
  USER_RANK: 300,
  TOP_PERFORMERS: 300,
  MCQ_COUNT: 600, // 10 minutes
  CHAPTER_COUNT: 600,
};

export default RedisClient;
