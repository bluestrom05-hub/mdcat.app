import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import { User, Subject, Board } from '../models';
import connectDB from '../config/database';

dotenv.config();

const seedData = async (): Promise<void> => {
  try {
    await connectDB();

    console.log('Starting database seeding...');

    // Create admin user
    const adminExists = await User.findOne({ email: process.env.ADMIN_EMAIL || 'admin@mdcat.com' });
    if (!adminExists) {
      const adminPassword = await bcrypt.hash(process.env.ADMIN_PASSWORD || 'admin123', 12);
      await User.create({
        name: 'Admin',
        email: process.env.ADMIN_EMAIL || 'admin@mdcat.com',
        password: adminPassword,
        role: 'admin',
        isPremium: true,
        premiumSince: new Date(),
      });
      console.log('Admin user created');
    } else {
      console.log('Admin user already exists');
    }

    // Create subjects
    const subjects = [
      { name: 'Physics', code: 'PHY', type: 'science' as const, description: 'Physics for MDCAT' },
      { name: 'Chemistry', code: 'CHEM', type: 'science' as const, description: 'Chemistry for MDCAT' },
      { name: 'Biology', code: 'BIO', type: 'science' as const, description: 'Biology for MDCAT' },
      { name: 'English', code: 'ENG', type: 'english' as const, description: 'English for MDCAT' },
      { name: 'Logical Reasoning', code: 'LR', type: 'logical' as const, description: 'Logical Reasoning for MDCAT' },
    ];

    for (const subjectData of subjects) {
      const exists = await Subject.findOne({ code: subjectData.code });
      if (!exists) {
        await Subject.create(subjectData);
        console.log(`Subject created: ${subjectData.name}`);
      } else {
        console.log(`Subject already exists: ${subjectData.name}`);
      }
    }

    // Create boards
    const boards = [
      { name: 'Khyber Pakhtunkhwa', code: 'KPK', description: 'KPK Board' },
      { name: 'Federal', code: 'FED', description: 'Federal Board' },
      { name: 'Punjab', code: 'PUN', description: 'Punjab Board' },
    ];

    for (const boardData of boards) {
      const exists = await Board.findOne({ code: boardData.code });
      if (!exists) {
        await Board.create(boardData);
        console.log(`Board created: ${boardData.name}`);
      } else {
        console.log(`Board already exists: ${boardData.name}`);
      }
    }

    console.log('Database seeding completed!');
    process.exit(0);
  } catch (error) {
    console.error('Seeding error:', error);
    process.exit(1);
  }
};

seedData();
