#!/bin/bash

# MDCAT Platform Deployment Script

set -e

echo "🚀 Starting MDCAT Platform Deployment..."

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Please install Docker first."
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose is not installed. Please install Docker Compose first."
    exit 1
fi

# Create necessary directories
echo "📁 Creating directories..."
mkdir -p data/mongodb
mkdir -p data/redis

# Build and start services
echo "🔨 Building and starting services..."
docker-compose down
docker-compose build --no-cache
docker-compose up -d

# Wait for services to be ready
echo "⏳ Waiting for services to be ready..."
sleep 10

# Check service health
echo "🏥 Checking service health..."
if curl -s http://localhost:5000/api/health > /dev/null; then
    echo "✅ Backend is healthy"
else
    echo "⚠️ Backend health check failed"
fi

# Seed database
echo "🌱 Seeding database..."
cd backend
npm install
npm run seed || echo "⚠️ Database seeding failed or already seeded"
cd ..

echo ""
echo "✅ Deployment Complete!"
echo ""
echo "🌐 Application URLs:"
echo "   Frontend: http://localhost"
echo "   Backend API: http://localhost:5000/api"
echo "   MongoDB: localhost:27017"
echo "   Redis: localhost:6379"
echo ""
echo "📋 Default Admin Credentials:"
echo "   Email: admin@mdcat.com"
echo "   Password: admin123"
echo ""
echo "📝 Useful Commands:"
echo "   View logs: docker-compose logs -f"
echo "   Stop: docker-compose down"
echo "   Restart: docker-compose restart"
echo ""
