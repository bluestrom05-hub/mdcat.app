# MDCAT Preparation Platform

A comprehensive, production-ready web platform for MDCAT (Medical and Dental College Admission Test) preparation.

## Features

### Core Features
- **Subject Management**: Physics, Chemistry, Biology, English, Logical Reasoning
- **Hierarchical Content Structure**: Subject → Board → Class → Book → Chapter → MCQ
- **MCQ Practice**: Practice by subject, chapter, or take full-length tests
- **Past Papers**: 180-mark, 180-minute full-length tests with timer
- **Monthly Competition**: +1 for correct, -1 for wrong scoring system
- **Leaderboard**: Real-time rankings with Redis caching
- **Hall of Fame**: Monthly winners stored permanently
- **Premium System**: 2500 PKR one-time payment for premium features

### Admin Features
- Full CRUD for subjects, boards, books, chapters, MCQs
- CSV bulk upload with validation and preview (up to 250 MCQs per upload)
- Past paper management
- User management with premium grant/revoke
- Monthly reset with Hall of Fame update
- Dashboard with statistics

### Technical Features
- JWT authentication with role-based access
- Rate limiting on API endpoints
- Redis caching for leaderboard
- MongoDB with proper indexing
- Chunked CSV processing for large files
- Input validation and sanitization
- Graceful error handling

## Tech Stack

### Backend
- Node.js 20+ with Express
- TypeScript
- MongoDB with Mongoose
- Redis for caching
- JWT for authentication
- Joi for validation

### Frontend
- React 18 with TypeScript
- Vite for build tooling
- Tailwind CSS with shadcn/ui
- React Query for data fetching
- Zustand for state management
- React Router for routing

## Project Structure

```
mdcat-platform/
├── backend/              # Node.js/Express API
│   ├── src/
│   │   ├── config/      # Database and Redis config
│   │   ├── controllers/ # Route controllers
│   │   ├── middleware/  # Auth, validation, rate limiting
│   │   ├── models/      # Mongoose models
│   │   ├── routes/      # API routes
│   │   ├── services/    # Business logic
│   │   ├── types/       # TypeScript types
│   │   └── utils/       # Utility functions
│   ├── package.json
│   ├── tsconfig.json
│   └── Dockerfile
├── frontend/            # React app (in /app)
│   ├── src/
│   │   ├── components/  # UI components
│   │   ├── contexts/    # React contexts
│   │   ├── pages/       # Page components
│   │   ├── services/    # API services
│   │   └── types/       # TypeScript types
│   ├── package.json
│   ├── vite.config.ts
│   └── Dockerfile
└── docker-compose.yml   # Docker orchestration
```

## Quick Start

### Prerequisites
- Node.js 20+
- MongoDB
- Redis
- Docker (optional)

### Local Development

1. **Clone the repository**
```bash
git clone <repository-url>
cd mdcat-platform
```

2. **Setup Backend**
```bash
cd backend
npm install
cp .env.example .env
# Edit .env with your configuration
npm run dev
```

3. **Setup Frontend**
```bash
cd ../app
npm install
cp .env.example .env
# Edit .env with your configuration
npm run dev
```

4. **Seed Database**
```bash
cd backend
npm run seed
```

### Docker Deployment

```bash
docker-compose up -d
```

This will start:
- MongoDB on port 27017
- Redis on port 6379
- Backend API on port 5000
- Frontend on port 80

## Environment Variables

### Backend (.env)
```
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/mdcat_platform
REDIS_URL=redis://localhost:6379
JWT_SECRET=your-secret-key
JWT_EXPIRES_IN=7d
FRONTEND_URL=http://localhost:5173
ADMIN_EMAIL=admin@mdcat.com
ADMIN_PASSWORD=admin123
```

### Frontend (.env)
```
VITE_API_URL=http://localhost:5000/api
```

## API Documentation

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `POST /api/auth/logout` - Logout user
- `GET /api/auth/profile` - Get user profile

### Subjects
- `GET /api/subjects` - List all subjects
- `POST /api/subjects` - Create subject (admin)
- `GET /api/subjects/:id` - Get subject details
- `DELETE /api/subjects/:id` - Delete subject (admin)

### MCQs
- `GET /api/mcqs` - List MCQs with filters
- `POST /api/mcqs` - Create MCQ (admin)
- `POST /api/mcqs/upload/preview` - Preview CSV upload (admin)
- `POST /api/mcqs/upload/confirm` - Confirm CSV upload (admin)

### Tests
- `POST /tests/practice/start` - Start practice session
- `POST /tests/past-paper/start` - Start past paper test
- `POST /tests/submit` - Submit test
- `GET /tests/history` - Get test history

### Leaderboard
- `GET /api/leaderboard` - Get leaderboard
- `GET /api/leaderboard/top-performers` - Get top 3 performers
- `GET /api/leaderboard/my-rank` - Get current user's rank

### Admin
- `GET /api/admin/dashboard` - Get dashboard stats
- `GET /api/admin/users` - List users
- `POST /api/admin/reset` - Trigger monthly reset

## CSV Upload Format

The CSV file should have the following columns:
```csv
question,optionA,optionB,optionC,optionD,correctAnswer,explanation
What is the capital of Pakistan?,Lahore,Karachi,Islamabad,Peshawar,C,Islamabad is the capital
```

## Content Limits

- Max 15 chapters per book
- Max 280 MCQs per chapter
- Max 500 MCQs for English
- Max 300 MCQs for Logical Reasoning
- Max 250 MCQs per CSV upload

## Scoring System

- +1 point for correct answer
- -1 point for wrong answer
- 0 points for unanswered

## Monthly Competition

- Competition runs monthly
- Top 3 winners get Premium status automatically
- Winners are stored in Hall of Fame
- Leaderboard resets on 1st of each month

## Security Features

- JWT authentication with HTTP-only cookies
- Role-based access control
- Rate limiting on all endpoints
- Input validation with Joi
- XSS and CSRF protection
- Helmet security headers

## Performance Optimizations

- Redis caching for leaderboard
- Database indexing on frequently queried fields
- Code splitting with lazy loading
- Pagination for large datasets
- Chunked CSV processing

## License

MIT License
